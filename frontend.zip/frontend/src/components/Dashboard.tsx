import React, { useEffect, useMemo, useState, useRef } from 'react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { useMetrics, useCampaigns } from '../hooks/useApi';
import DashboardShell from './dashboard/DashboardShell';
import {
  LayoutDashboard,
  BarChart3,
  Search,
  ShoppingBag,
  Users,
  Settings,
  FileText,
  TrendingUp,
  Filter,
  RefreshCw,
  ArrowUpRight,
  ArrowDownRight,
  CheckSquare,
  Share2,
  Bell,
  Calendar,
} from 'lucide-react';
import { MetricsLineChart, MetricsBarChart, PlatformPieChart, ChartDatum } from './Charts';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip as RechartsTooltip,
  Legend,
  ComposedChart,
  Area,
  Line,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  mockOverviewHighlights,
  mockPlatformShare,
  mockCampaignList,
  mockSeoSnapshots,
  mockSeoRealtimeStats,
  mockSeoTechnicalScores,
  mockSeoKeywordsDetailed,
  mockSeoCompetitors,
  mockSeoPositionDistribution,
  mockSeoCompetitiveMap,
  mockSeoConversionSummary,
  mockSeoIssues,
  mockSeoAuthorityScores,
  mockSeoBacklinkHighlights,
  mockSeoOrganicSearch,
  mockSeoAnchors,
  mockSeoReferringDomains,
  mockSeoRegionalPerformance,
  mockSeoRightRailStats,
  mockSeoUrlRatings,
  mockCommerceInsights,
  mockCommerceRealtime,
  mockCommerceProfitability,
  mockCommerceConversionFunnel,
  mockCommerceRevenueTrend,
  mockCommerceProductVideos,
  mockCommerceCreatives,
  mockOverviewRealtime,
  mockCrmPipeline,
  mockCrmRealtime,
  mockCrmStages,
  mockCrmAgeRange,
  mockCrmLeads,
  mockTrendInsights,
  mockTrendRealtime,
  mockTrendRevenueByChannel,
  mockTrendSalesFunnel,
  mockTrendRevenueTrend,
  mockTrendLeadSources,
  mockTrendSalesReps,
  mockSettingsShortcuts,
  mockSettingsKpis,
  mockSettingsBranding,
  mockSettingsRefresh,
  mockSettingsIntegrations,
  mockSettingsUsers,
  mockSettingsAlerts,
  mockReportAutomation,
  mockReportBuilders,
  mockReportStatus,
  mockRealtimeStats,
  mockFinancialOverview,
  mockConversionFunnel,
  mockLtvTrend,
  mockConversionPlatforms,
  mockProductPerformance,
  mockCampaignSourceInsights,
  mockNotifications,
} from '../data/mockDashboard';

type SectionKey =
  | 'overview'
  | 'commerce'
  | 'campaign'
  | 'trend'
  | 'crm'
  | 'seo'
  | 'settings'
  | 'reports';

const hexToRgba = (hex: string | undefined, alpha = 1) => {
  if (!hex) return `rgba(249, 115, 22, ${alpha})`;
  let sanitized = hex.replace('#', '');
  if (![3, 6].includes(sanitized.length)) {
    return `rgba(249, 115, 22, ${alpha})`;
  }
  if (sanitized.length === 3) {
    sanitized = sanitized
      .split('')
      .map((char) => char + char)
      .join('');
  }
  const bigint = parseInt(sanitized, 16);
  const r = (bigint >> 16) & 255;
  const g = (bigint >> 8) & 255;
  const b = bigint & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
};

const accentGradient = (hex: string | undefined, startAlpha = 0.12, endAlpha = 0.35) =>
  `linear-gradient(135deg, ${hexToRgba(hex, startAlpha)}, ${hexToRgba(hex, endAlpha)})`;

interface StatConfig {
  label: string;
  value: string;
  helper?: string;
}

const StatCard: React.FC<StatConfig> = ({ label, value, helper }) => (
  <div className="bg-white rounded-2xl px-4 py-5 border border-gray-100 shadow-sm">
    <p className="text-xs font-semibold text-gray-500 uppercase tracking-[0.24em]">{label}</p>
    <p className="mt-2 text-3xl font-semibold text-gray-900">{value}</p>
    {helper && <p className="text-xs text-gray-500">{helper}</p>}
  </div>
);

const RealTimeCard: React.FC<{
  label: string;
  value: string;
  delta: string;
  positive?: boolean;
  active?: boolean;
  onSelect?: () => void;
  detail?: string;
}> = ({ label, value, delta, positive = true, active = false, onSelect, detail }) => {
  const interactive = Boolean(onSelect);
  const detailText = detail || delta || 'More insight coming soon.';
  const handleKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (!interactive || !onSelect) return;
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onSelect();
    }
  };

  return (
    <div
      role={interactive ? 'button' : undefined}
      tabIndex={interactive ? 0 : undefined}
      onClick={onSelect}
      onKeyDown={handleKeyDown}
      className={`relative overflow-hidden group rounded-[36px] border px-9 py-9 text-left transition bg-gradient-to-br from-white to-orange-50/20 shadow-[0_28px_80px_rgba(15,23,42,0.1)] flex flex-col gap-2 ${
        active
          ? 'border-gray-900 ring-2 ring-gray-900/10 shadow-[0_32px_90px_rgba(15,23,42,0.15)] translate-y-0'
          : 'border-gray-200 hover:-translate-y-1'
      } ${interactive ? 'cursor-pointer focus:outline-none focus:ring-2 focus:ring-gray-900/30' : ''}`}
    >
      <div className="flex items-center justify-between text-[16px] font-semibold uppercase tracking-[0.32em] text-gray-500">
        <span>{label}</span>
        <span className={`h-2.5 w-2.5 rounded-full ${active ? 'bg-gray-900' : 'bg-gray-300'}`} />
      </div>
      <p className="text-[60px] leading-tight font-bold text-gray-900 tracking-tight -mt-2">{value}</p>
      <div
        className={`inline-flex items-center gap-2 text-[21px] font-semibold px-7 py-3.5 rounded-full w-fit -mt-2 ${
          positive ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-500'
        }`}
      >
        {positive ? <ArrowUpRight className="h-5.5 w-5.5" /> : <ArrowDownRight className="h-5.5 w-5.5" />}
        {delta}
      </div>
      <p className="text-[19px] text-gray-500 -mt-1">from last period</p>
          </div>
  );
};

const ReportBuilderCard: React.FC<{ builder: typeof mockReportBuilders.builders[0]; actionLabel: string }> = ({ builder, actionLabel }) => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Report</p>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
      <div>
        <p className="text-xs text-gray-500">Name Report</p>
        <p className="mt-1 font-semibold text-gray-900">{builder.name}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Menu</p>
        <p className="mt-1 font-semibold text-gray-900">{builder.menu}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Date Range</p>
        <p className="mt-1 font-semibold text-gray-900">{builder.dateRange}</p>
      </div>
    </div>
    <div>
      <p className="text-xs uppercase tracking-[0.2em] text-gray-500">Format</p>
      <div className="mt-2 flex flex-wrap gap-3">
        {builder.format.map((format) => (
          <button key={format} className="rounded-2xl border border-gray-200 px-4 py-2 text-sm font-semibold text-gray-700">
            {format}
          </button>
        ))}
      </div>
    </div>
    <button className="w-full rounded-full border border-gray-200 bg-gray-50 py-2 text-sm font-semibold text-gray-700 hover:border-gray-400">
      {actionLabel}
    </button>
  </div>
);

const ScheduleReportCard: React.FC<{ schedule: typeof mockReportBuilders.schedule }> = ({ schedule }) => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Schedule Report</p>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
      <div>
        <p className="text-xs text-gray-500">Name Report</p>
        <p className="mt-1 font-semibold text-gray-900">{schedule.name}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Menu</p>
        <p className="mt-1 font-semibold text-gray-900">{schedule.menu}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Date Range</p>
        <p className="mt-1 font-semibold text-gray-900">{schedule.dateRange}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Schedule Time</p>
        <p className="mt-1 font-semibold text-gray-900">{schedule.scheduleTime}</p>
      </div>
    </div>
    <div>
      <p className="text-xs uppercase tracking-[0.2em] text-gray-500">Email Recipients</p>
      <div className="mt-2 flex flex-wrap gap-2">
        {schedule.recipients.map((email) => (
          <span key={email} className="rounded-full bg-gray-100 px-3 py-1 text-xs text-gray-700">
            {email}
          </span>
        ))}
      </div>
    </div>
    <div>
      <p className="text-xs uppercase tracking-[0.2em] text-gray-500">Format</p>
      <div className="mt-2 flex flex-wrap gap-3">
        {mockReportBuilders.builders[0].format.map((format) => (
          <button key={format} className="rounded-2xl border border-gray-200 px-4 py-2 text-sm font-semibold text-gray-700">
            {format}
          </button>
        ))}
      </div>
    </div>
    <button className="w-full rounded-full border border-gray-200 bg-gray-50 py-2 text-sm font-semibold text-gray-700 hover:border-gray-400">
      Schedule Report
    </button>
  </div>
);

const ReportStatusTable: React.FC = () => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Report Status</p>
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-[0.2em] text-gray-500">
            <th className="py-2 pr-4">Name</th>
            <th className="py-2 pr-4">Role</th>
            <th className="py-2 pr-4">Status</th>
            <th className="py-2">Date</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {mockReportStatus.map((row) => (
            <tr key={row.email} className="text-gray-800">
              <td className="py-3 pr-4">
                <p className="font-semibold">{row.name}</p>
                <p className="text-xs text-gray-400">{row.email}</p>
              </td>
              <td className="py-3 pr-4">
                <span className="px-3 py-1 rounded-full bg-gray-900 text-white text-xs">{row.role}</span>
              </td>
              <td className="py-3 pr-4">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    row.status === 'Download'
                      ? 'bg-blue-50 text-blue-600'
                      : row.status === 'Scheduled'
                      ? 'bg-amber-50 text-amber-600'
                      : 'bg-emerald-50 text-emerald-600'
                  }`}
                >
                  {row.status}
                </span>
              </td>
              <td className="py-3">{row.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const KpiSettingsTable: React.FC = () => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-semibold text-gray-900">KPI Setup & Thresholds</p>
        <p className="text-xs text-gray-500">Configure alert logic for every dashboard</p>
      </div>
      <button className="px-3 py-1 rounded-full border border-gray-200 text-xs">+ Add KPI</button>
    </div>
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-[0.2em] text-gray-500">
            <th className="py-2 pr-4">Alert Name</th>
            <th className="py-2 pr-4">Metric</th>
            <th className="py-2 pr-4">Condition</th>
            <th className="py-2">Threshold</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {mockSettingsKpis.map((kpi) => (
            <tr key={kpi.id} className="text-gray-800">
              <td className="py-3 pr-4">{kpi.alertName}</td>
              <td className="py-3 pr-4">{kpi.metric}</td>
              <td className="py-3 pr-4">{kpi.condition}</td>
              <td className="py-3">{kpi.threshold}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const ThemeBrandingCard: React.FC = () => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Theme & Branding</p>
    <div className="grid grid-cols-2 gap-4 text-sm">
      <div>
        <p className="text-xs text-gray-500">Color Theme</p>
        <p className="mt-1 font-semibold text-gray-900">{mockSettingsBranding.theme}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Accent Color</p>
        <div className="mt-1 flex items-center gap-2">
          <span className="h-6 w-6 rounded-full border" style={{ backgroundColor: mockSettingsBranding.accentColor }} />
          <span className="font-semibold">{mockSettingsBranding.accentColor}</span>
        </div>
      </div>
      <div>
        <p className="text-xs text-gray-500">Color Menu</p>
        <div className="mt-1 flex items-center gap-2">
          <span className="h-6 w-6 rounded-full border" style={{ backgroundColor: mockSettingsBranding.menuColor }} />
          <span className="font-semibold">{mockSettingsBranding.menuColor}</span>
        </div>
      </div>
      <div>
        <p className="text-xs text-gray-500">Company Name</p>
        <p className="mt-1 font-semibold text-gray-900">{mockSettingsBranding.companyName}</p>
      </div>
    </div>
    <div className="space-y-2 text-sm">
      <p className="text-xs text-gray-500">Company Logo</p>
      <div className="flex items-center gap-3">
        <div className="h-12 w-12 rounded-2xl border border-dashed border-gray-200 flex items-center justify-center text-xs text-gray-400">
          Logo
        </div>
        <button className="px-3 py-1 rounded-full border border-gray-200 text-xs">Upload Logo</button>
      </div>
    </div>
  </div>
);

const DataRefreshCard: React.FC = () => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Data Refresh Schedule</p>
    <div className="space-y-3 text-sm">
      <div>
        <p className="text-xs text-gray-500">Refresh Frequency</p>
        <p className="mt-1 font-semibold text-gray-900">{mockSettingsRefresh.frequency}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Refresh Manual</p>
        <p className="mt-1 font-semibold text-gray-900">{mockSettingsRefresh.manual}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Refresh Real-Time</p>
        <p className="mt-1 font-semibold text-gray-900">{mockSettingsRefresh.realtime}</p>
      </div>
    </div>
  </div>
);

const ApiIntegrationCard: React.FC = () => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">API Integration</p>
    <div className="space-y-3">
      {mockSettingsIntegrations.map((integration) => (
        <div key={integration.id} className="flex items-center justify-between rounded-2xl border border-gray-100 p-3">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center text-sm font-semibold text-gray-500">
              {integration.name[0]}
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-900">{integration.name}</p>
              <p className="text-xs text-gray-500">{integration.syncedAt}</p>
            </div>
          </div>
          <button
            className={`px-3 py-1 rounded-full text-xs font-semibold border ${
              integration.status === 'Connected' ? 'border-emerald-200 text-emerald-600 bg-emerald-50' : 'border-gray-200 text-gray-600'
            }`}
          >
            {integration.status}
          </button>
        </div>
      ))}
    </div>
  </div>
);

const UserRolesCard: React.FC = () => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <div className="flex items-center justify-between">
      <p className="text-sm font-semibold text-gray-900">User Roles & Permissions</p>
      <button className="px-3 py-1 rounded-full border border-gray-200 text-xs">+ Add User</button>
    </div>
    <div className="space-y-3 text-sm">
      {mockSettingsUsers.map((user) => (
        <div key={user.id} className="flex items-center justify-between rounded-2xl border border-gray-100 p-3">
          <div>
            <p className="font-semibold text-gray-900">{user.name}</p>
            <p className="text-xs text-gray-500">{user.email}</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-gray-900 text-white text-xs">{user.role}</span>
            <span className="text-xs text-emerald-600">{user.status}</span>
          </div>
        </div>
      ))}
    </div>
    <div className="text-xs text-gray-500">
      <p>Role Permissions:</p>
      <p>Admin: Access to all features and configuration.</p>
      <p>Analyst: View-only dashboards, reports, and KPIs.</p>
      <p>Executive: View-only access to dashboards and reports.</p>
    </div>
  </div>
);

const AlertSettingsCard: React.FC = () => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Alert & Notification Settings</p>
    <div className="space-y-4 text-sm">
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-gray-500">Alert Types</p>
        <div className="mt-2 space-y-2">
          {mockSettingsAlerts.alertTypes.map((alert) => (
            <label key={alert.label} className="flex items-center justify-between text-gray-700">
              <span>{alert.label}</span>
              <input type="checkbox" checked={alert.enabled} readOnly className="h-4 w-4 rounded border-gray-300" />
            </label>
          ))}
        </div>
      </div>
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-gray-500">Delivery Channels</p>
        <div className="mt-2 space-y-2">
          {mockSettingsAlerts.deliveryChannels.map((channel) => (
            <label key={channel.label} className="flex items-center justify-between text-gray-700">
              <span>{channel.label}</span>
              <input type="checkbox" checked={channel.enabled} readOnly className="h-4 w-4 rounded border-gray-300" />
            </label>
          ))}
        </div>
      </div>
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-gray-500">Email Recipients</p>
        <div className="mt-2 space-y-2">
          {mockSettingsAlerts.recipients.map((email) => (
            <div key={email} className="rounded-2xl border border-gray-100 px-3 py-2 text-gray-700">
              {email}
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

const SeoConversionCard: React.FC<{ summary: typeof mockSeoConversionSummary }> = ({ summary }) => {
  return (
    <div className="rounded-3xl border border-orange-100 bg-gradient-to-br from-white to-orange-50/30 p-6 space-y-6 shadow-[0_25px_60px_rgba(249,115,22,0.12)]">
      <header className="space-y-2">
        <span className="px-3 py-1 inline-flex rounded-full border border-orange-200 text-[11px] uppercase tracking-[0.35em] text-orange-500 bg-white">
          Conversions · SEO
        </span>
        <h3 className="text-3xl lg:text-[36px] font-semibold text-gray-900 leading-tight">Register SEO Conversions</h3>
      </header>
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        <div className="relative w-full max-w-xs h-48">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={summary.breakdown}
                dataKey="value"
                nameKey="label"
                innerRadius="55%"
                outerRadius="80%"
                paddingAngle={4}
                stroke="#fff"
                strokeWidth={2}
              >
                {summary.breakdown.map((segment) => (
                  <Cell key={segment.label} fill={segment.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
            <p className="text-[11px] uppercase tracking-[0.35em] text-gray-400">Total</p>
            <p className="text-4xl font-bold text-gray-900">{summary.total.toLocaleString('en-US')}</p>
          </div>
        </div>
        <div className="flex-1 space-y-3 text-center lg:text-left">
          <div className="flex flex-wrap items-center gap-4 justify-center lg:justify-start">
            <div className="rounded-full bg-emerald-50 border border-emerald-200 px-4 py-2 text-sm font-semibold text-emerald-600 flex items-center gap-2">
              <span className="inline-flex h-2 w-2 rounded-full bg-emerald-500" />
              {summary.delta}
            </div>
          </div>
          <p className="rounded-2xl bg-white/90 border border-orange-100 px-4 py-3 text-sm text-gray-600">
            Track how each segment contributes to the total goal. The highest values bubble to the top so you can focus instantly.
          </p>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
        {summary.breakdown.map((item) => (
          <div key={item.label} className="flex items-center justify-between rounded-2xl border border-orange-100 bg-white/90 px-4 py-3">
            <div className="flex items-center gap-3">
              <span className="h-3 w-3 rounded-full" style={{ backgroundColor: item.color }} />
              <span className="text-gray-700 font-medium">{item.label}</span>
            </div>
            <span className="font-semibold text-gray-900">{item.value.toLocaleString('en-US')}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const ChannelComparisonChart: React.FC<{ data: typeof mockTrendRevenueByChannel }> = ({ data }) => {
  const max = Math.max(...data.flatMap((d) => [d.revenue, d.cost]), 1);
  return (
    <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
      <p className="text-sm font-semibold text-gray-900">Revenue and costs by channel</p>
      <div className="space-y-4">
        {data.map((item) => (
          <div key={item.channel}>
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>{item.channel}</span>
              <span>${item.revenue}K</span>
            </div>
            <div className="mt-2 space-y-1">
              <div className="h-3 rounded-full bg-pink-200">
                <div className="h-full rounded-full bg-pink-500" style={{ width: `${(item.revenue / max) * 100}%` }} />
              </div>
              <div className="h-3 rounded-full bg-gray-200">
                <div className="h-full rounded-full bg-gray-500" style={{ width: `${(item.cost / max) * 100}%` }} />
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="flex items-center gap-4 text-xs text-gray-500">
        <span className="inline-flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-pink-500" />Revenue</span>
        <span className="inline-flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-gray-500" />Cost</span>
      </div>
    </div>
  );
};

const SalesFunnelChart: React.FC<{ stages: typeof mockTrendSalesFunnel }> = ({ stages }) => {
  const max = Math.max(...stages.map((stage) => stage.value), 1);
  return (
    <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
      <p className="text-sm font-semibold text-gray-900">Sales Funnel</p>
      <div className="space-y-4">
        {stages.map((stage) => (
          <div key={stage.stage} className="space-y-1">
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>{stage.stage}</span>
              <span>{stage.value.toLocaleString()}</span>
            </div>
            <div className="h-6 rounded-full bg-emerald-100">
              <div className="h-full rounded-full bg-emerald-500" style={{ width: `${(stage.value / max) * 100}%` }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const RevenueTrendChart: React.FC<{ data: typeof mockTrendRevenueTrend }> = ({ data }) => {
  const max = Math.max(...data.map((point) => point.revenue), 1);
  const points = data
    .map((point, idx) => {
      const x = (idx / (data.length - 1)) * 100;
      const y = 100 - (point.revenue / max) * 100;
      return `${x},${y}`;
    })
    .join(' ');

  return (
    <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
      <p className="text-sm font-semibold text-gray-900">Revenue Trend</p>
      <div className="h-64">
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full text-purple-500">
          <polyline fill="none" stroke="currentColor" strokeWidth="2" points={points} />
          <polyline fill="rgba(167,139,250,0.2)" stroke="none" points={`0,100 ${points} 100,100`} />
        </svg>
      </div>
      <div className="flex justify-between text-xs text-gray-500">
        {data.map((point) => (
          <span key={point.month}>{point.month}</span>
        ))}
      </div>
    </div>
  );
};

const YtdRevenueCard: React.FC<{ data: typeof mockTrendRevenueTrend }> = ({ data }) => {
  const total = data.reduce((sum, point) => sum + point.revenue, 0);
  const peak = data.reduce((prev, curr) => (curr.revenue > prev.revenue ? curr : prev), data[0]);
  const low = data.reduce((prev, curr) => (curr.revenue < prev.revenue ? curr : prev), data[0]);
  const avg = Math.round(total / data.length);
  return (
    <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
      <p className="text-sm font-semibold text-gray-900">YTD revenue</p>
      <p className="text-3xl font-bold text-indigo-600">${(total / 1000).toFixed(0)}K</p>
      <p className="text-xs text-gray-500">+2.5% from last period</p>
      <div className="space-y-2 text-sm">
        <div className="flex items-center justify-between">
          <span className="text-gray-500">Peak: ${peak.revenue.toLocaleString()} ({peak.month})</span>
          <span className="text-emerald-600 text-xs">+2.8%</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-gray-500">Lowest: ${low.revenue.toLocaleString()} ({low.month})</span>
          <span className="text-red-500 text-xs">-3.7%</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-gray-500">Average: ${avg.toLocaleString()}</span>
          <span className="text-emerald-600 text-xs">+2.3%</span>
        </div>
      </div>
    </div>
  );
};

const LeadSourceTable: React.FC<{ sources: typeof mockTrendLeadSources }> = ({ sources }) => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Where Leads Come From</p>
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-[0.2em] text-gray-500">
            <th className="py-2 pr-4">Source</th>
            <th className="py-2 pr-4">Leads</th>
            <th className="py-2 pr-4">Cost</th>
            <th className="py-2 pr-4">Revenue</th>
            <th className="py-2">ROI</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {sources.map((row) => (
            <tr key={row.source} className="text-gray-800">
              <td className="py-3 pr-4 font-semibold">{row.source}</td>
              <td className="py-3 pr-4">{row.leads}</td>
              <td className="py-3 pr-4">${row.cost.toLocaleString()}</td>
              <td className="py-3 pr-4">${row.revenue.toLocaleString()}</td>
              <td className="py-3">{row.roi}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const SalesRepTable: React.FC<{ reps: typeof mockTrendSalesReps }> = ({ reps }) => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Who Closed The Deal</p>
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-[0.2em] text-gray-500">
            <th className="py-2 pr-4">Sales Rep</th>
            <th className="py-2 pr-4">Leads Assigned</th>
            <th className="py-2 pr-4">Conversion Rate</th>
            <th className="py-2">Revenue Closed</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {reps.map((rep) => (
            <tr key={rep.rep} className="text-gray-800">
              <td className="py-3 pr-4 font-semibold">{rep.rep}</td>
              <td className="py-3 pr-4">{rep.leadsAssigned}</td>
              <td className="py-3 pr-4">{rep.conversionRate}</td>
              <td className="py-3">{rep.revenue}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const CrmStageChart: React.FC<{ stages: typeof mockCrmStages }> = ({ stages }) => {
  const max = Math.max(...stages.map((stage) => stage.value), 1);
  return (
    <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
      <p className="text-sm font-semibold text-gray-900">Pipeline status</p>
      <div className="space-y-3">
        {stages.map((stage) => (
          <div key={stage.label} className="space-y-1">
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>{stage.label}</span>
              <span>{stage.value.toFixed(1)}x</span>
            </div>
            <div className="h-6 rounded-full bg-gray-100">
              <div className="h-full rounded-full" style={{ width: `${(stage.value / max) * 100}%`, backgroundColor: stage.color }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const CrmAgeDonut: React.FC<{ ranges: typeof mockCrmAgeRange }> = ({ ranges }) => {
  const total = ranges.reduce((sum, range) => sum + range.customers, 0) || 1;
  let cumulative = 0;
  const gradients = ranges.map((range) => {
    const from = (cumulative / total) * 100;
    cumulative += range.customers;
    const to = (cumulative / total) * 100;
    return `${range.color} ${from}% ${to}%`;
  });

  return (
    <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
      <p className="text-sm font-semibold text-gray-900">Age Range</p>
      <div className="flex items-center gap-4">
        <div className="h-36 w-36 rounded-full" style={{ background: `conic-gradient(${gradients.join(', ')})` }}>
          <div className="h-full w-full flex items-center justify-center">
            <div className="h-18 w-18 rounded-full bg-white flex flex-col items-center justify-center">
              <p className="text-xl font-semibold text-gray-900">{total}</p>
              <p className="text-xs text-gray-500">Customers</p>
            </div>
          </div>
        </div>
        <div className="space-y-2 text-sm">
          {ranges.map((range) => (
            <div key={range.label} className="grid grid-cols-4 gap-2 items-center">
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: range.color }} />
                <span className="text-gray-700">{range.label}</span>
              </div>
              <span className="text-gray-500">{range.customers}</span>
              <span className="text-gray-500">{range.value}</span>
              <span className="font-semibold text-gray-900">{range.roi}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const LeadTrackingTable: React.FC<{ leads: typeof mockCrmLeads }> = ({ leads }) => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-semibold text-gray-900">Lead Tracking</p>
        <p className="text-xs text-gray-500">7 leads</p>
      </div>
      <button className="px-3 py-1 rounded-full border border-gray-200 text-xs">Export</button>
    </div>
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-[0.2em] text-gray-500">
            <th className="py-2 pr-4">Lead</th>
            <th className="py-2 pr-4">Company</th>
            <th className="py-2 pr-4">Source</th>
            <th className="py-2 pr-4">Status</th>
            <th className="py-2 pr-4">Value</th>
            <th className="py-2">Date</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {leads.map((lead) => (
            <tr key={`${lead.lead}-${lead.company}`} className="text-gray-800">
              <td className="py-3 pr-4">
                <p className="font-semibold">{lead.lead}</p>
                <p className="text-xs text-gray-400">{lead.lead.toLowerCase().replace(' ', '.')}@example.com</p>
              </td>
              <td className="py-3 pr-4">{lead.company}</td>
              <td className="py-3 pr-4">{lead.source}</td>
              <td className="py-3 pr-4">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    lead.status === 'Converted'
                      ? 'bg-emerald-50 text-emerald-600'
                      : lead.status === 'In Progress'
                      ? 'bg-amber-50 text-amber-600'
                      : lead.status === 'Lost'
                      ? 'bg-red-50 text-red-600'
                      : 'bg-blue-50 text-blue-600'
                  }`}
                >
                  {lead.status}
                </span>
              </td>
              <td className="py-3 pr-4">{lead.value}</td>
              <td className="py-3">{lead.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const CommerceFunnelChart: React.FC<{ steps: typeof mockCommerceConversionFunnel }> = ({ steps }) => {
  const max = steps[0]?.value || 1;
  const animated = useAnimatedReveal();
  return (
    <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
      <p className="text-sm font-semibold text-gray-900">Conversion Rate</p>
      <div className="space-y-2">
        {steps.map((step, index) => {
          const width = ((steps.length - index) / steps.length) * 100;
          return (
            <div key={step.label} className="flex flex-col items-center gap-1">
              <div
                className="rounded-full h-8 transition-all duration-700 ease-out"
                style={{ width: animated ? `${width}%` : '0%', backgroundColor: step.color }}
              />
              <div className="text-xs text-gray-600 flex items-center gap-2">
                <span className="font-semibold text-gray-900">{step.label}</span>
                <span>{step.value}%</span>
              </div>
            </div>
          );
        })}
      </div>
      <div className="flex flex-wrap gap-3 text-xs text-gray-500">
        {steps.map((step) => (
          <span key={step.label} className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full" style={{ backgroundColor: step.color }} />
            {step.label}
          </span>
        ))}
      </div>
    </div>
  );
};

const SeoIssuesCard: React.FC<{ issues: typeof mockSeoIssues }> = ({ issues }) => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Platform health</p>
    <div className="space-y-3">
      {issues.map((issue) => (
        <div key={issue.label} className="flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold text-gray-900">{issue.label}</p>
            <p className="text-xs text-gray-500">{issue.helper}</p>
          </div>
          <span className={`text-sm font-semibold ${issue.positive ? 'text-emerald-600' : 'text-orange-500'}`}>{issue.value}</span>
        </div>
      ))}
    </div>
  </div>
);

const SectionTitle: React.FC<{ title: string; subtitle?: string; actions?: React.ReactNode; badge?: React.ReactNode }> = ({
  title,
  subtitle,
  actions,
  badge,
}) => (
  <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
    <div className="space-y-2 max-w-4xl">
      <h2 className="text-[32px] leading-snug md:text-[42px] font-semibold text-gray-900 tracking-tight break-words">{title}</h2>
      {subtitle && <p className="text-[22px] text-gray-500 leading-relaxed break-words">{subtitle}</p>}
    </div>
    {(badge || actions) && (
      <div className="flex items-center gap-2">
        {badge}
        {actions}
      </div>
    )}
  </div>
);

const ZeroState: React.FC<{ message?: string }> = ({ message }) => (
  <div className="bg-gradient-to-br from-white to-orange-50 border border-dashed border-orange-200 rounded-3xl p-6 text-center">
    <p className="text-lg font-semibold text-gray-900">No data available</p>
    <p className="text-sm text-gray-500 mt-2">{message || 'Sample data only • connect your live API sources when ready'}</p>
  </div>
);

const AlertBadge: React.FC<{ label: string; severity?: 'info' | 'warning' | 'success' }> = ({ label, severity = 'info' }) => {
  const styles = {
    info: 'bg-blue-100 text-blue-700',
    warning: 'bg-amber-100 text-amber-800',
    success: 'bg-emerald-100 text-emerald-700',
  };
  return <span className={`px-3 py-1 rounded-full text-xs font-semibold ${styles[severity]}`}>{label}</span>;
};

const NotificationCenter: React.FC = () => {
  const [open, setOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handleClick = (event: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [open]);

  const severityClass = (severity: string) => {
    if (severity === 'warning') return 'bg-amber-50 border-amber-100 text-amber-800';
    if (severity === 'success') return 'bg-emerald-50 border-emerald-100 text-emerald-800';
    return 'bg-blue-50 border-blue-100 text-blue-800';
  };

  return (
    <div className="relative" ref={panelRef}>
      <button
        className="relative inline-flex items-center justify-center rounded-full border border-gray-200 bg-white p-2 text-gray-700 hover:border-gray-300"
        onClick={() => setOpen((prev) => !prev)}
        aria-label="Notifications"
      >
        <Bell className="h-4 w-4" />
        <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-red-500 text-[10px] font-semibold text-white flex items-center justify-center">
          {mockNotifications.length}
        </span>
      </button>
      {open && (
        <div className="absolute right-0 mt-3 w-80 rounded-3xl border border-gray-100 bg-white p-4 shadow-2xl z-20">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-semibold text-gray-900">Notifications</p>
            <button className="text-xs text-gray-500" onClick={() => setOpen(false)}>
              Close
            </button>
          </div>
          <div className="space-y-3 max-h-80 overflow-auto">
            {mockNotifications.map((notification) => (
              <div
                key={notification.id}
                className={`rounded-2xl border p-3 space-y-1 ${severityClass(notification.severity)}`}
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold">{notification.title}</span>
                  <span>{notification.time}</span>
                </div>
                <p className="text-sm">{notification.message}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const useAnimatedReveal = () => {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const frame = requestAnimationFrame(() => setReady(true));
    return () => cancelAnimationFrame(frame);
  }, []);
  return ready;
};

const ProfitabilityChart: React.FC<{ data: typeof mockCommerceProfitability }> = ({ data }) => {
  return (
    <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <p className="text-base font-semibold text-gray-900">Profitability and Cost Analysis</p>
          <p className="text-sm text-gray-500">Budget vs cost vs revenue snapshot</p>
        </div>
        <div className="flex items-center gap-3 text-sm">
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-2 text-emerald-600 font-semibold">
            Final Cash Balance
          </div>
          <div className="text-right">
            <p className="text-xs uppercase tracking-[0.3em] text-gray-400">Growth</p>
            <p className="text-lg font-semibold text-emerald-600">+5.8% from last period</p>
          </div>
        </div>
      </div>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
            <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="label" tickLine={false} tick={{ fontSize: 12, fill: '#475569' }} />
            <YAxis tickLine={false} tick={{ fontSize: 12, fill: '#475569' }} tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`} />
            <RechartsTooltip formatter={(value, name) => [`THB ${Number(value).toLocaleString('en-US')}`, name]} />
            <Bar dataKey="value" barSize={32} radius={[12, 12, 0, 0]}>
              {data.map((entry) => (
                <Cell key={entry.label} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
        {data.map((item) => (
          <div key={item.label} className="flex items-center gap-3 rounded-2xl border border-gray-100 bg-white px-3 py-2">
            <span className="h-3 w-3 rounded-full" style={{ backgroundColor: item.color }} />
            <div>
              <p className="font-semibold text-gray-900">{item.label}</p>
              <p className="text-xs text-gray-500">THB {item.value.toLocaleString('en-US')}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const RevenueOrdersTrendChart: React.FC<{ data: typeof mockCommerceRevenueTrend }> = ({ data }) => {
  return (
    <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-4">
      <div className="space-y-2">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-base font-semibold text-gray-900">Revenue & Orders Trend</p>
            <p className="text-sm text-gray-500">6-month revenue bars with order trend line</p>
          </div>
          <span className="text-[11px] uppercase tracking-[0.3em] text-gray-400">Mock</span>
        </div>
        <div className="flex items-center justify-end gap-6 text-xs font-semibold text-gray-500">
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-[#f97316]" />
            <span>Revenue</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-[#ef4444]" />
            <span>Orders</span>
          </div>
        </div>
      </div>
      <div className="flex flex-col lg:flex-row gap-6">
        <div className="lg:w-1/2">
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="4 4" stroke="#f1f5f9" />
                <XAxis dataKey="month" tickLine={false} tick={{ fontSize: 12, fill: '#475569' }} />
                <YAxis
                  yAxisId="left"
                  tick={{ fontSize: 12, fill: '#475569' }}
                  tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                  domain={[0, 'auto']}
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  tick={{ fontSize: 12, fill: '#475569' }}
                  tickFormatter={(value) => `${value}`}
                  domain={[0, 'auto']}
                />
                <RechartsTooltip
                  formatter={(value, name) => {
                    if (name === 'orders') return [Number(value).toLocaleString('en-US'), 'Orders'];
                    return [`THB ${Number(value).toLocaleString('en-US')}`, 'Revenue'];
                  }}
                />
                <Bar
                  yAxisId="left"
                  dataKey="revenue"
                  name="Revenue"
                  fill="#f97316"
                  barSize={28}
                  radius={[10, 10, 0, 0]}
                />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="orders"
                  name="Orders"
                  stroke="#ef4444"
                  strokeWidth={3}
                  dot={{ r: 4, fill: '#ef4444', strokeWidth: 2, stroke: '#fff' }}
                  activeDot={{ r: 5 }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="flex-1 rounded-2xl border-2 border-dashed border-gray-200 bg-gray-50/70 flex items-center justify-center text-sm text-gray-400 text-center p-6">
          Space reserved for future Revenue & Orders detail cards or KPIs
        </div>
      </div>
    </div>
  );
};

const DonutChart: React.FC<{ segments: { name: string; value: number; color: string }[] }> = ({ segments }) => {
  const total = segments.reduce((sum, seg) => sum + seg.value, 0);
  let cumulative = 0;
  const animated = useAnimatedReveal();
  const gradients = segments.map((seg) => {
    const from = (cumulative / total) * 100;
    cumulative += seg.value;
    const to = (cumulative / total) * 100;
    return `${seg.color} ${from}% ${to}%`;
  });
  return (
    <div className="flex items-center justify-between gap-8">
      <div
        className="h-64 w-64 rounded-full transition-transform duration-700 ease-out flex-shrink-0"
        style={{
          background: `conic-gradient(${gradients.join(', ')})`,
          transform: animated ? 'scale(1)' : 'scale(0.85)',
        }}
      >
        <div className="h-full w-full flex items-center justify-center">
          <div className="h-32 w-32 rounded-full bg-white flex flex-col items-center justify-center">
            <p className="text-sm font-semibold text-gray-800">Total</p>
            <p className="text-2xl font-bold text-black">{(total / 1000000).toFixed(1)}M</p>
          </div>
        </div>
      </div>
      <div className="flex-1 space-y-4 text-sm">
        {segments.map((seg) => (
          <div key={seg.name} className="flex items-center justify-between p-3 rounded-lg bg-gray-50/50">
            <div className="flex items-center gap-3">
              <span className="h-4 w-4 rounded-full flex-shrink-0" style={{ backgroundColor: seg.color }} />
              <span className="font-medium text-gray-800">{seg.name}</span>
            </div>
            <span className="font-semibold text-gray-900">THB {(seg.value / 1000000).toFixed(2)}M</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const SeoSparkline: React.FC<{ values: number[]; color?: string }> = ({ values, color = '#f97316' }) => {
  if (!values.length) return null;
  const max = Math.max(...values);
  const min = Math.min(...values);
  const range = Math.max(max - min, 1);
  const points = values
    .map((value, index) => {
      const x = (index / (values.length - 1 || 1)) * 100;
      const y = 100 - ((value - min) / range) * 100;
      return `${x},${y}`;
    })
    .join(' ');

  return (
    <svg viewBox="0 0 100 100" className="w-full h-16">
      <polyline points={points} fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" />
    </svg>
  );
};

const SearchVisibilityCard: React.FC<{ snapshot: typeof mockSeoSnapshots }> = ({ snapshot }) => {
  const gaugeValue = snapshot.healthScore;
  return (
    <div className="rounded-3xl border border-gray-100 p-6 space-y-6 bg-white">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-base font-semibold text-gray-900">Search Visibility</p>
          <p className="text-sm text-gray-500">Live health and ranking signals</p>
        </div>
        <span className="text-xs text-gray-400">Updated 5 min ago</span>
      </div>
      <div className="flex flex-col lg:flex-row lg:items-center gap-8">
        <div className="flex items-center gap-6">
          <div className="relative h-36 w-36">
            <div
              className="absolute inset-0 rounded-full"
              style={{
                background: `conic-gradient(#f97316 ${gaugeValue}%, #f3f4f6 ${gaugeValue}% 100%)`,
              }}
            />
            <div className="absolute inset-3 rounded-full bg-white flex flex-col items-center justify-center">
              <p className="text-3xl font-semibold text-gray-900">{gaugeValue}%</p>
              <p className="text-xs uppercase tracking-[0.3em] text-gray-500">Health</p>
            </div>
          </div>
          <div className="space-y-4 text-gray-900">
            <div>
              <p className="text-[11px] uppercase tracking-[0.35em] text-gray-500">Avg. Position</p>
              <p className="text-3xl font-semibold">{snapshot.avgPosition}</p>
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-[0.35em] text-gray-500">Organic Sessions</p>
              <p className="text-3xl font-semibold">{snapshot.organicSessions.toLocaleString('en-US')}</p>
            </div>
          </div>
        </div>
        <div className="flex-1 border-t lg:border-t-0 lg:border-l border-dashed border-gray-200 pt-6 lg:pt-0 lg:pl-8">
          <p className="text-[11px] uppercase tracking-[0.35em] text-gray-500">Sessions (7d)</p>
          <p className="text-base font-medium text-gray-900">Week-on-week trend</p>
          <SeoSparkline values={snapshot.sessionTrend} />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-base">
        {snapshot.keywords.map((keyword) => (
          <div key={keyword.keyword} className="rounded-2xl border border-gray-100 p-4 space-y-1">
            <p className="text-sm text-gray-500 truncate">{keyword.keyword}</p>
            <p className="text-2xl font-semibold text-gray-900">#{keyword.position}</p>
            <p className="text-sm text-emerald-500">{keyword.change} • Vol. {keyword.volume.toLocaleString('en-US')}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

const TechnicalScoreList: React.FC<{ scores: typeof mockSeoTechnicalScores }> = ({ scores }) => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Technical Readiness</p>
    <div className="space-y-3">
      {scores.map((item) => (
        <div key={item.label} className="flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold text-gray-900">{item.label}</p>
            <p className="text-xs text-gray-500">{item.helper}</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-gray-900">{item.value}%</span>
            <div className="w-24 h-2 rounded-full bg-gray-100">
              <div className="h-2 rounded-full bg-gradient-to-r from-orange-500 to-pink-500" style={{ width: `${item.value}%` }} />
            </div>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const SeoChannelMix: React.FC<{ channels: typeof mockSeoSnapshots.channels }> = ({ channels }) => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Organic Channel Mix</p>
    <div className="space-y-3 text-sm">
      {channels.map((channel) => (
        <div key={channel.label}>
          <div className="flex items-center justify-between text-xs text-gray-500">
            <span>{channel.label}</span>
            <span>{channel.value}%</span>
          </div>
          <div className="mt-1 h-2 rounded-full bg-gray-100">
            <div className="h-full rounded-full" style={{ width: `${channel.value}%`, backgroundColor: channel.color }} />
          </div>
        </div>
      ))}
    </div>
  </div>
);

const SeoKeywordsTable: React.FC<{ keywords: typeof mockSeoKeywordsDetailed }> = ({ keywords }) => (
  <div className="rounded-3xl border-2 border-[#0066ff]/20 bg-white p-5 shadow-md">
    <div className="flex items-center justify-between mb-4">
      <div>
        <p className="text-sm font-semibold text-gray-900">Top Organic Keywords (07)</p>
        <p className="text-xs text-gray-500">Most impactful search queries</p>
      </div>
      <button className="px-3 py-1 rounded-full border border-blue-100 text-xs font-medium text-blue-600">View All</button>
    </div>
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-[0.2em] text-gray-500">
            <th className="py-2 pr-4">Keywords</th>
            <th className="py-2 pr-4">Pos.</th>
            <th className="py-2 pr-4">Volume</th>
            <th className="py-2 pr-4">CPUT(THB)</th>
            <th className="py-2">Traffic %</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {keywords.map((row, index) => (
            <tr key={`${row.keyword}-${index}`} className="text-gray-800">
              <td className="py-3 pr-4 font-semibold text-blue-600">{row.keyword}</td>
              <td className="py-3 pr-4">{row.pos}</td>
              <td className="py-3 pr-4">
                <span className="inline-flex items-center px-2 py-1 rounded-md bg-yellow-100 text-yellow-700 text-xs font-semibold">
                  {row.volume}
                </span>
              </td>
              <td className="py-3 pr-4">{row.cpu.toLocaleString('en-US')}</td>
              <td className="py-3">{row.traffic}%</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const SeoCompetitorsCard: React.FC<{ competitors: typeof mockSeoCompetitors }> = ({ competitors }) => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <div className="flex items-center justify-between">
      <p className="text-sm font-semibold text-gray-900">Top organic Competitors</p>
      <button className="px-3 py-1 rounded-full border border-gray-200 text-xs">View All</button>
    </div>
    <div className="space-y-3 text-sm">
      {competitors.map((competitor) => (
        <div key={competitor.name} className="flex items-center justify-between">
          <div>
            <p className="font-semibold text-gray-900">{competitor.name}</p>
            <p className="text-xs text-gray-500">Com. Level {competitor.competition}</p>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs text-gray-500">Com.keyWords {competitor.keywords}</span>
            <div className="px-3 py-1 rounded-full bg-blue-50 text-blue-600 text-xs font-semibold">
              {competitor.refDomains}
            </div>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const SeoBacklinkSummaryCard: React.FC = () => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Backlinks overview</p>
    <div className="grid grid-cols-2 gap-4 text-sm">
      <div>
        <p className="text-xs text-gray-500">Backlinks</p>
        <p className="text-2xl font-semibold text-gray-900">{mockSeoBacklinkHighlights.totalBacklinks}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Referring Domains</p>
        <p className="text-2xl font-semibold text-gray-900">{mockSeoBacklinkHighlights.referringDomains}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Keywords</p>
        <p className="text-2xl font-semibold text-gray-900">{mockSeoBacklinkHighlights.keywords}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Traffic Cost</p>
        <p className="text-2xl font-semibold text-gray-900">{mockSeoBacklinkHighlights.trafficCost}</p>
      </div>
    </div>
    <div className="grid grid-cols-2 gap-4 text-sm">
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-gray-500 mb-2">Anchors</p>
        <div className="space-y-2">
          {mockSeoAnchors.map((anchor) => (
            <div key={anchor.anchor} className="flex items-center justify-between">
              <span className="text-gray-700 truncate pr-2">{anchor.anchor}</span>
              <span className="font-semibold text-gray-900">{anchor.percent}%</span>
            </div>
          ))}
        </div>
      </div>
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-gray-500 mb-2">Referring domains</p>
        <div className="space-y-2">
          {mockSeoReferringDomains.map((item) => (
            <div key={item.label} className="flex items-center justify-between">
              <span className="text-gray-600">{item.label}</span>
              <span className="font-semibold text-gray-900">{item.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

const SeoRightRailCard: React.FC = () => (
  <div className="rounded-3xl border border-blue-100 bg-blue-50/30 p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Crawled metrics</p>
    <div className="space-y-2 text-sm">
      {mockSeoRightRailStats.map((stat) => (
        <div key={stat.label} className="flex items-center justify-between">
          <span>{stat.label}</span>
          <span className="font-semibold text-gray-900">{stat.value}</span>
        </div>
      ))}
    </div>
    <div>
      <p className="text-xs uppercase tracking-[0.2em] text-gray-500 mb-2">URL Rating Distribution</p>
      <div className="space-y-2">
        {mockSeoUrlRatings.map((rating) => (
          <div key={rating.label} className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: rating.label === '81-100' ? '#22c55e' : rating.label === '61-80' ? '#10b981' : rating.label === '41-60' ? '#facc15' : rating.label === '21-40' ? '#fb923c' : '#f87171' }} />
              <span>{rating.label}</span>
            </div>
            <span className="text-gray-700">{rating.value} • {rating.percent}</span>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const SeoRegionalPerformanceCard: React.FC = () => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Regional SEO Performance</p>
    <div className="flex items-center gap-4">
      <div className="h-32 w-32 rounded-full" style={{ background: `conic-gradient(${mockSeoRegionalPerformance.map((r) => `${r.color} ${r.value}%`).join(', ')})` }}>
        <div className="h-full w-full flex items-center justify-center">
          <div className="h-16 w-16 rounded-full bg-white flex items-center justify-center text-2xl font-semibold text-gray-900">110</div>
        </div>
      </div>
      <div className="space-y-2 text-sm">
        {mockSeoRegionalPerformance.map((region) => (
          <div key={region.region} className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: region.color }} />
            <span className="w-20 text-gray-600">{region.region}</span>
            <span className="font-semibold text-gray-900">{region.value}</span>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const SeoAuthorityCard: React.FC = () => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
    <p className="text-sm font-semibold text-gray-900">Authority metrics</p>
    <div className="grid grid-cols-2 gap-4">
      {mockSeoAuthorityScores.map((score) => (
        <div key={score.label} className="rounded-2xl border border-gray-100 p-3">
          <p className="text-xs uppercase tracking-[0.2em] text-gray-500">{score.label}</p>
          <div className="flex items-center gap-3">
            <span className="text-3xl font-bold text-gray-900">{score.value}</span>
            <div className="flex-1 h-2 rounded-full bg-gray-100">
              <div className="h-full rounded-full bg-gradient-to-r from-green-400 to-lime-500" style={{ width: `${score.value}%` }} />
            </div>
          </div>
          <p className="text-xs text-gray-500">{score.helper}</p>
        </div>
      ))}
    </div>
  </div>
);

const SeoOrganicSummaryCard: React.FC = () => (
  <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-3">
    <p className="text-sm font-semibold text-gray-900">Organic Search</p>
    <div className="grid grid-cols-3 gap-4 text-sm">
      <div>
        <p className="text-xs text-gray-500">Keywords</p>
        <p className="text-xl font-semibold text-gray-900">{mockSeoOrganicSearch.keywords}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Traff. Cost</p>
        <p className="text-xl font-semibold text-gray-900">{mockSeoOrganicSearch.trafficCost}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500">Traffic</p>
        <p className="text-xl font-semibold text-gray-900">{mockSeoOrganicSearch.traffic}</p>
      </div>
    </div>
  </div>
);

const SeoPositionDistributionCard: React.FC<{ distribution: typeof mockSeoPositionDistribution }> = ({ distribution }) => {
  const max = Math.max(...distribution.map((item) => item.value), 1);
  return (
    <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
      <p className="text-sm font-semibold text-gray-900">Organic Position Distribution</p>
      <div className="space-y-3">
        {distribution.map((item) => (
          <div key={item.range}>
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>{item.range}</span>
              <span>{item.value}%</span>
            </div>
            <div className="mt-1 h-3 rounded-full bg-gray-100">
              <div className="h-full rounded-full bg-gradient-to-r from-orange-500 to-pink-500" style={{ width: `${(item.value / max) * 100}%` }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const SeoCompetitiveMapCard: React.FC<{ snapshot: typeof mockSeoCompetitiveMap }> = ({ snapshot }) => (
  <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-5">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div>
        <p className="text-base font-semibold text-gray-900">Competitive Positioning Map</p>
        <p className="text-sm text-gray-500">Authority vs share of voice • mock SERP data</p>
      </div>
      <div className="flex items-center gap-3 text-xs text-gray-500">
        <span>↑ Authority</span>
        <span className="px-2 py-1 rounded-full border border-gray-200">→ Momentum</span>
      </div>
    </div>
    <div className="relative h-64 bg-gradient-to-br from-slate-50 to-white rounded-3xl border border-gray-100 overflow-hidden">
      <div className="absolute inset-6 border border-dashed border-gray-200 rounded-2xl">
        {snapshot.map((brand) => (
          <div
            key={brand.brand}
            className="absolute flex flex-col items-center"
            style={{
              left: `${brand.authority * 0.9}%`,
              bottom: `${brand.share * 0.8}%`,
            }}
          >
            <div
              className="rounded-full shadow-lg text-xs font-semibold text-white flex items-center justify-center"
              style={{
                width: `${Math.max(32, brand.share / 1.5)}px`,
                height: `${Math.max(32, brand.share / 1.5)}px`,
                background: `linear-gradient(135deg, ${hexToRgba(brand.color, 0.9)}, ${hexToRgba(brand.color, 0.6)})`,
              }}
            >
              {brand.brand}
            </div>
            <span className="mt-1 text-[11px] text-gray-500">{brand.share}% SoV</span>
          </div>
        ))}
      </div>
    </div>
    <div className="flex flex-wrap items-center justify-between text-xs text-gray-500">
      <span>Bubble size = share of voice</span>
      <span>Position = authority & momentum</span>
    </div>
  </div>
);

type CampaignSource = typeof mockCampaignSourceInsights[number];

const AgeRangeDonut: React.FC<{ ranges: CampaignSource['ageRange'] }> = ({ ranges }) => {
  const total = ranges.reduce((sum, range) => sum + range.value, 0) || 1;
  const topRange = ranges.reduce((prev, curr) => (curr.value > prev.value ? curr : prev), ranges[0]);

  return (
    <div className="flex flex-col lg:flex-row items-center gap-8 w-full">
      <div className="relative flex-1 min-w-[220px]">
        <ResponsiveContainer width="100%" height={260}>
          <PieChart>
            <Pie
              data={ranges}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              innerRadius="55%"
              outerRadius="85%"
              paddingAngle={3}
              stroke="#fff"
              strokeWidth={2}
            >
              {ranges.map((entry) => (
                <Cell key={entry.name} fill={entry.color} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
          <p className="text-xs uppercase tracking-[0.35em] text-gray-400">Top</p>
          <p className="text-4xl font-bold text-gray-900 leading-tight">{topRange?.value}%</p>
        </div>
      </div>
      <div className="flex-1 w-full space-y-4">
        <div className="rounded-2xl border border-orange-100 bg-orange-50/70 px-4 py-2 flex flex-wrap items-center gap-3 shadow-sm">
          <span className="text-[11px] uppercase tracking-[0.35em] text-orange-500">Top Range</span>
          <span className="text-sm font-semibold text-gray-900">{topRange?.name}</span>
          <span className="text-sm text-gray-500">({((topRange?.value || 0) / total) * 100}% of audience)</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {ranges.map((range) => (
            <div key={range.name} className="flex items-center gap-3 bg-orange-50/30 rounded-2xl px-3 py-2">
              <span className="h-3 w-3 rounded-full" style={{ backgroundColor: range.color }} />
              <div className="flex flex-col">
                <span className="text-sm font-semibold text-gray-900">{range.value}%</span>
                <span className="text-xs text-gray-500">{range.name}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const ConversionRateBars: React.FC<{ data: CampaignSource['conversionRate'] }> = ({ data }) => {
  const [activeLabel, setActiveLabel] = useState(data[0]?.label || '');
  const activeMetric = useMemo(() => data.find((item) => item.label === activeLabel) || data[0], [data, activeLabel]);
  const best = useMemo(() => data.reduce((prev, curr) => (curr.value > prev.value ? curr : prev), data[0]), [data]);
  const lowest = useMemo(() => data.reduce((prev, curr) => (curr.value < prev.value ? curr : prev), data[0]), [data]);

  if (!data.length) {
    return <p className="text-sm text-gray-500">No conversion data available.</p>;
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2">
        {data.map((item) => {
          const isActive = item.label === activeMetric?.label;
          return (
            <button
              key={item.label}
              onClick={() => setActiveLabel(item.label)}
              className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${
                isActive ? 'bg-gray-900 text-white border-gray-900 shadow-lg' : 'border-gray-200 text-gray-700 hover:border-gray-400'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </div>
      <div className="rounded-3xl border border-gray-100 bg-white/90 p-6 space-y-5 shadow-inner">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.35em] text-gray-400">Active Channel</p>
            <p className="text-lg font-semibold text-gray-900">{activeMetric?.label}</p>
          </div>
          <div className="text-right">
            <p className="text-xs uppercase tracking-[0.35em] text-gray-400">Conversion Rate</p>
            <p className="text-4xl font-bold text-gray-900">{activeMetric?.value}%</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="rounded-2xl bg-orange-50/70 border border-orange-100 p-4">
            <p className="text-xs uppercase tracking-[0.3em] text-orange-500">Insight</p>
            <p className="text-sm text-gray-700 mt-1">
              {activeMetric?.label} converts {((activeMetric!.value / best.value - 1) * 100).toFixed(1)}% {activeMetric?.value === best.value ? 'higher than average' : 'vs best channel'} driven by optimized targeting.
            </p>
          </div>
          <div className="rounded-2xl bg-gray-50 border border-gray-100 p-4">
            <p className="text-xs uppercase tracking-[0.3em] text-gray-500">Benchmark</p>
            <p className="text-sm text-gray-700 mt-1">
              Top: {best.label} ({best.value}%). Lowest: {lowest.label} ({lowest.value}%). Keep {activeMetric?.label.toLowerCase()} above {best.value - 2}% to stay competitive.
            </p>
          </div>
          <div className="rounded-2xl bg-emerald-50 border border-emerald-100 p-4">
            <p className="text-xs uppercase tracking-[0.3em] text-emerald-600">Action</p>
            <p className="text-sm text-gray-700 mt-1">Double down on creatives performing in {activeMetric?.label}. Test new offer variants to close the gap with {best.label}.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const GenderDistributionChart: React.FC<{ data: CampaignSource['genderDistribution'] }> = ({ data }) => {
  const chartData = data.map((segment) => ({
    segment: segment.segment,
    Male: segment.male,
    Female: segment.female,
    Unknown: segment.unknown,
  }));

  const colors = {
    Male: '#3b82f6',
    Female: '#ec4899',
    Unknown: '#94a3b8',
  };

  return (
    <div className="space-y-4">
      <ResponsiveContainer width="100%" height={380}>
        <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 40 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis dataKey="segment" tickLine={false} tick={{ fontSize: 11, fill: '#475569' }} interval={0} angle={-8} height={60} />
          <YAxis tick={{ fontSize: 11, fill: '#475569' }} />
          <RechartsTooltip cursor={{ fill: 'rgba(59,130,246,0.08)' }} />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          {(['Male', 'Female', 'Unknown'] as const).map((key) => (
            <Bar key={key} dataKey={key} fill={colors[key]} radius={[10, 10, 0, 0]} barSize={24} />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

const CampaignSourceTabs: React.FC<{ sources: CampaignSource[] }> = ({ sources }) => {
  const [activeSourceId, setActiveSourceId] = useState(sources[0]?.id || '');
  const [chartTheme, setChartTheme] = useState<'sunset' | 'carbon'>('sunset');

  const activeSource = useMemo(() => {
    if (!sources.length) return null;
    return sources.find((source) => source.id === activeSourceId) || sources[0];
  }, [sources, activeSourceId]);

  const palette = useMemo(() => {
    const accent = activeSource?.accent || '#f97316';
    return chartTheme === 'sunset'
      ? {
          primary: accent,
          secondary: '#fef08a',
          tertiary: '#fb923c',
          card: 'from-white to-orange-50/40',
          border: 'border-orange-100',
          text: 'text-gray-900',
          subtext: 'text-gray-600',
          legend: '#0f172a',
          area: 'rgba(249, 115, 22, 0.18)',
        }
      : {
          primary: '#0f172a',
          secondary: '#475569',
          tertiary: '#f97316',
          card: 'from-gray-900 via-gray-800 to-gray-900',
          border: 'border-gray-800',
          text: 'text-white',
          subtext: 'text-gray-300',
          legend: '#e5e7eb',
          area: 'rgba(15, 23, 42, 0.35)',
        };
  }, [activeSource, chartTheme]);

  const budgetVsSpendData = useMemo(() => {
    if (!activeSource) return [];
    return activeSource.campaigns.map((campaign) => ({
      name: campaign.name,
      budget: campaign.budget,
      spent: campaign.spent,
      roi: campaign.roi,
    }));
  }, [activeSource]);

  const efficiencyData = useMemo(() => {
    if (!activeSource) return [];
    return activeSource.adPerformance.map((item) => ({
      campaign: item.campaign,
      impressions: item.impressions,
      clicks: item.clicks,
      ctr: item.ctr,
      cpc: item.cpc,
    }));
  }, [activeSource]);

  const statusClasses = (status: string) => {
    const normalized = status.toLowerCase();
    if (normalized === 'active') return 'bg-emerald-100 text-emerald-700';
    if (normalized === 'learning') return 'bg-amber-100 text-amber-700';
    if (normalized === 'paused') return 'bg-gray-200 text-gray-700';
    return 'bg-gray-100 text-gray-600';
  };

  if (!activeSource) {
    return <ZeroState message="No sample campaign is available for this platform yet" />;
  }

  const currentSourceId = activeSource.id;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {sources.map((source) => {
          const isActive = source.id === currentSourceId;
          const activeStyle = isActive
            ? {
                background: accentGradient(source.accent, 0.25, 0.85),
                borderColor: 'transparent',
                color: '#fff',
                boxShadow: `0 18px 35px ${hexToRgba(source.accent, 0.35)}`,
              }
            : undefined;
          return (
            <button
              key={source.id}
              onClick={() => setActiveSourceId(source.id)}
              aria-pressed={isActive}
              className={`flex items-center gap-4 rounded-2xl border px-5 py-4 transition ${
                isActive
                  ? 'text-white'
                  : 'bg-white text-gray-800 border-gray-200 hover:border-gray-400 shadow-sm'
              }`}
              style={activeStyle}
            >
              <div
                className={`h-12 w-12 rounded-2xl flex items-center justify-center ${
                  isActive ? 'bg-white/20 backdrop-blur border border-white/30' : 'bg-white'
                }`}
              >
                <img src={source.logo} alt={source.label} className="h-7 w-7 object-contain" />
              </div>
              <div className="text-left">
                <p className={`text-[11px] uppercase tracking-[0.35em] ${isActive ? 'text-white/80' : 'text-gray-500'}`}>Ads</p>
                <p className="text-base font-semibold">{source.label}</p>
              </div>
            </button>
          );
        })}
      </div>

      <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-6">
        <div>
          <p className="text-base font-semibold text-gray-900">Real-Time Analytics</p>
          <p className="text-sm text-gray-500">Updated on mock data • swap with live API anytime</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          {activeSource.summary.map((stat) => (
            <RealTimeCard key={stat.id} label={stat.label} value={stat.value} delta={stat.delta} positive={stat.positive} />
          ))}
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full text-base">
            <thead>
              <tr className="text-left text-[12px] uppercase tracking-[0.2em] text-gray-500">
                <th className="py-3 pr-6">Campaign</th>
                <th className="py-3 pr-6">Date</th>
                <th className="py-3 pr-6">Status</th>
                <th className="py-3 pr-6">Budget</th>
                <th className="py-3 pr-6">Spent</th>
                <th className="py-3 pr-6">Conversions</th>
                <th className="py-3 pr-6">ROI</th>
                <th className="py-3">Show</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {activeSource.campaigns.map((campaign) => (
                <tr key={campaign.id} className="text-gray-800">
                  <td className="py-4 pr-6 font-semibold text-gray-900">{campaign.name}</td>
                  <td className="py-4 pr-6 text-gray-500">{campaign.date}</td>
                  <td className="py-4 pr-6">
                    <span className={`px-4 py-1.5 rounded-full text-[12px] font-semibold capitalize ${statusClasses(campaign.status)}`}>
                      {campaign.status}
                    </span>
                  </td>
                  <td className="py-4 pr-6">THB {campaign.budget.toLocaleString('en-US')}</td>
                  <td className="py-4 pr-6">THB {campaign.spent.toLocaleString('en-US')}</td>
                  <td className="py-4 pr-6">{campaign.conversions.toLocaleString('en-US')}</td>
                  <td className="py-4 pr-6">{campaign.roi}%</td>
                  <td className="py-4">
                    <button className="rounded-full border border-gray-200 p-2 hover:border-gray-400">
                      <CheckSquare className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-base font-semibold text-gray-900">Visualization Controls</p>
            <p className="text-sm text-gray-500">Add more context with themed charts and mock trends</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {(
              [
                { key: 'sunset', label: 'Sunset Amber' },
                { key: 'carbon', label: 'Carbon Noir' },
              ] as const
            ).map((option) => (
              <button
                key={option.key}
                onClick={() => setChartTheme(option.key)}
                className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${
                  chartTheme === option.key ? 'bg-gray-900 text-white border-gray-900 shadow-lg' : 'border-gray-200 text-gray-700 hover:border-gray-400'
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          <div className={`rounded-2xl border ${palette.border} bg-gradient-to-br ${palette.card} p-4 space-y-4 shadow-inner transition-colors`}>
            <div className="flex items-center justify-between">
              <div>
                <p className={`text-sm font-semibold ${palette.text}`}>Budget vs Spend</p>
                <p className={`text-xs ${palette.subtext}`}>Includes ROI overlay for the latest campaigns</p>
              </div>
              <span className={`text-[11px] uppercase tracking-[0.3em] ${palette.subtext}`}>Mock</span>
            </div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={budgetVsSpendData} margin={{ top: 10, right: 20, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="4 4" stroke={chartTheme === 'carbon' ? '#1f2937' : '#fed7aa'} />
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 11, fill: chartTheme === 'carbon' ? '#e2e8f0' : '#475569' }}
                    tickLine={false}
                    interval={0}
                    angle={-8}
                    height={60}
                  />
                  <YAxis
                    yAxisId="left"
                    tick={{ fontSize: 11, fill: chartTheme === 'carbon' ? '#e2e8f0' : '#475569' }}
                    tickFormatter={(value) => `${value / 1000}k`}
                  />
                  <YAxis
                    yAxisId="right"
                    orientation="right"
                    tick={{ fontSize: 11, fill: chartTheme === 'carbon' ? '#e2e8f0' : '#475569' }}
                    tickFormatter={(value) => `${value}%`}
                  />
                  <RechartsTooltip
                    cursor={{ fill: chartTheme === 'carbon' ? 'rgba(15,23,42,0.35)' : 'rgba(249,115,22,0.1)' }}
                    formatter={(value, name: string) => {
                      if (name === 'roi') return [`${value}%`, 'ROI'];
                      return [`THB ${Number(value).toLocaleString('en-US')}`, name === 'budget' ? 'Budget' : 'Spend'];
                    }}
                  />
                  <Legend wrapperStyle={{ color: palette.legend }} />
                  <Bar yAxisId="left" dataKey="budget" fill={palette.secondary} radius={[12, 12, 0, 0]} maxBarSize={42} name="Budget" />
                  <Bar yAxisId="left" dataKey="spent" fill={palette.primary} radius={[12, 12, 0, 0]} maxBarSize={42} name="Spend" />
                  <Line yAxisId="right" type="monotone" dataKey="roi" stroke={palette.tertiary} strokeWidth={3} dot={{ r: 4 }} name="ROI" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="rounded-2xl border border-gray-100 bg-white p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-gray-900">Engagement Mix</p>
                <p className="text-xs text-gray-500">Clicks & CTR stacked against impressions</p>
              </div>
              <span className="text-[11px] uppercase tracking-[0.3em] text-gray-400">Mock</span>
            </div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={efficiencyData} margin={{ top: 10, right: 20, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="4 4" stroke="#f1f5f9" />
                  <XAxis dataKey="campaign" tickLine={false} tick={{ fontSize: 11, fill: '#475569' }} interval={0} angle={-8} height={60} />
                  <YAxis
                    yAxisId="left"
                    tick={{ fontSize: 11, fill: '#475569' }}
                    tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                  />
                  <YAxis
                    yAxisId="right"
                    orientation="right"
                    tick={{ fontSize: 11, fill: '#475569' }}
                    tickFormatter={(value) => `${value}%`}
                  />
                  <RechartsTooltip
                    formatter={(value, name: string) => {
                      if (name === 'ctr') return [`${value}%`, 'CTR'] as [string, string];
                      if (name === 'cpc') return [`$${Number(value).toFixed(2)}`, 'CPC'];
                      if (name === 'clicks') return [Number(value).toLocaleString('en-US'), 'Clicks'];
                      return [Number(value).toLocaleString('en-US'), 'Impressions'];
                    }}
                  />
                  <Legend />
                  <Area
                    yAxisId="left"
                    type="monotone"
                    dataKey="impressions"
                    fill="url(#impressionGradient)"
                    stroke="#cbd5f5"
                    name="Impressions"
                  />
                  <Bar yAxisId="left" dataKey="clicks" barSize={26} radius={[10, 10, 0, 0]} fill="#f97316" name="Clicks" />
                  <Line yAxisId="right" type="monotone" dataKey="ctr" stroke="#0f172a" strokeWidth={3} dot={{ r: 4 }} name="CTR" />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
            <svg width="0" height="0">
              <defs>
                <linearGradient id="impressionGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f97316" stopOpacity="0.45" />
                  <stop offset="100%" stopColor="#fb923c" stopOpacity="0.05" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-blue-600 text-white text-xs font-semibold tracking-[0.3em] uppercase">Age Range</span>
            <span className="text-xs uppercase tracking-[0.35em] text-gray-400">Demographic mix</span>
          </div>
          <AgeRangeDonut ranges={activeSource.ageRange} />
        </div>
        <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-4">
          <p className="text-lg font-semibold text-gray-900">Detailed Ad Performance</p>
          <div className="overflow-x-auto">
            <table className="min-w-full text-lg">
              <thead>
                <tr className="text-left text-[14px] uppercase tracking-[0.2em] text-gray-500">
                  <th className="py-4 pr-6">Campaign</th>
                  <th className="py-4 pr-6">Spend</th>
                  <th className="py-4 pr-6">Impressions</th>
                  <th className="py-4 pr-6">Clicks</th>
                  <th className="py-4 pr-6">CTR</th>
                  <th className="py-4 pr-6">CPC</th>
                  <th className="py-4 pr-6">CPM</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {activeSource.adPerformance.map((campaign) => (
                  <tr key={campaign.campaign} className="text-gray-800">
                    <td className="py-5 pr-6 font-semibold text-gray-900">{campaign.campaign}</td>
                    <td className="py-5 pr-6">{campaign.spend}</td>
                    <td className="py-5 pr-6">{campaign.impressions.toLocaleString('en-US')}</td>
                    <td className="py-5 pr-6">{campaign.clicks.toLocaleString('en-US')}</td>
                    <td className="py-5 pr-6">{campaign.ctr}%</td>
                    <td className="py-5 pr-6">{campaign.cpc}</td>
                    <td className="py-5 pr-6">{campaign.cpm}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-4">
          <div>
            <p className="text-lg font-semibold text-gray-900">Gender Distribution</p>
            <p className="text-sm text-gray-500">Audience balance by campaign segments</p>
          </div>
          <GenderDistributionChart data={activeSource.genderDistribution} />
        </div>
        <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-lg font-semibold text-gray-900">Conversion Rate</p>
              <p className="text-sm text-gray-500">Channel-by-channel AI insights</p>
            </div>
            <span className="text-[11px] uppercase tracking-[0.3em] text-gray-400">Live mock</span>
          </div>
          <ConversionRateBars data={activeSource.conversionRate} />
        </div>
      </div>

      <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
        <div className="flex items-center justify-between">
          <p className="text-sm font-semibold text-gray-900">Detailed from {activeSource.label}</p>
          <p className="text-xs text-gray-500">Creative previews</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {activeSource.creatives.map((creative, index) => (
            <div key={creative.id} className="rounded-3xl border border-gray-100 bg-white p-4 space-y-4 shadow-sm">
              <div
                className="relative h-32 rounded-3xl overflow-hidden group"
                style={{
                  background: index % 3 === 0
                    ? 'linear-gradient(135deg, #0f172a, #1d4ed8)'
                    : index % 3 === 1
                    ? 'linear-gradient(135deg, #4c1d95, #db2777)'
                    : 'linear-gradient(135deg, #0f766e, #22d3ee)',
                }}
              >
                <div className="absolute inset-0 flex items-center justify-center">
                  <button className="h-12 w-12 rounded-full bg-white/90 text-gray-900 flex items-center justify-center shadow-lg group-hover:scale-105 transition">
                    ▶
                  </button>
                </div>
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-white/90">
                  <span className="px-2 py-1 rounded-full bg-black/30 backdrop-blur">AI Auto-Edit</span>
                  <span className="px-2 py-1 rounded-full bg-white/20">30s Vertical</span>
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-base font-semibold text-gray-900 flex items-center gap-2">
                  <span className="inline-flex h-2 w-2 rounded-full bg-emerald-500"></span>
                  {creative.name}
                </p>
                <p className="text-xs text-gray-500">AI video · {creative.type}</p>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
                <div>
                  <p className="text-[11px] uppercase tracking-[0.2em] text-gray-400">Reach</p>
                  <p className="font-semibold text-gray-900">{creative.reach.toLocaleString('en-US')}</p>
                </div>
                <div className="text-right">
                  <p className="text-[11px] uppercase tracking-[0.2em] text-gray-400">Reactions</p>
                  <p className="font-semibold text-gray-900">{creative.reactions.toLocaleString('en-US')}</p>
                </div>
              </div>
              <div className="flex items-center justify-between text-xs text-gray-500">
                <span>{creative.cta} CTA</span>
                <button className="inline-flex items-center gap-1 text-gray-900 font-semibold">
                  <span>Generate variants</span>
                  <RefreshCw className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const LtvComparisonChart: React.FC<{ data: { label: string; ltv: number; cac: number }[] }> = ({ data }) => {
  const max = Math.max(...data.flatMap((d) => [d.ltv, d.cac])) || 1;
  const animated = useAnimatedReveal();

  return (
    <div className="relative h-60">
      <div className="absolute inset-0 flex flex-col justify-between">
        {Array.from({ length: 5 }).map((_, idx) => (
          <div key={idx} className="w-full border-t border-dashed border-gray-100" />
        ))}
      </div>
      <div className="relative z-10 flex items-end gap-4 h-full">
        {data.map((item) => (
          <div key={item.label} className="flex-1">
            <div className="flex items-end justify-center gap-2 h-48">
              <div className="flex flex-col items-center gap-1">
                <div
                  className="w-10 rounded-t-2xl bg-gradient-to-t from-orange-600 to-amber-300 shadow-lg transition-all duration-700 ease-out"
                  style={{ height: animated ? `${(item.ltv / max) * 100}%` : '0%' }}
                />
                <span className="text-xs font-semibold text-gray-900">THB {item.ltv.toLocaleString('en-US')}</span>
                <span className="text-[11px] uppercase tracking-wide text-orange-500">LTV</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <div
                  className="w-10 rounded-t-2xl bg-gradient-to-t from-indigo-600 to-purple-400 shadow-lg transition-all duration-700 ease-out"
                  style={{ height: animated ? `${(item.cac / max) * 100}%` : '0%' }}
                />
                <span className="text-xs font-semibold text-gray-900">THB {item.cac.toLocaleString('en-US')}</span>
                <span className="text-[11px] uppercase tracking-wide text-indigo-500">CAC</span>
              </div>
            </div>
            <p className="mt-3 text-xs text-center text-gray-500 uppercase">{item.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

const ConversionPlatformBars: React.FC<{ data: { platform: string; value: number }[] }> = ({ data }) => {
  const max = Math.max(...data.map((item) => item.value)) || 1;
  const animated = useAnimatedReveal();

  return (
    <div className="space-y-6">
      <div className="relative h-72 pt-8">
        <div className="absolute inset-0 flex flex-col justify-between">
          {Array.from({ length: 5 }).map((_, idx) => (
            <div key={idx} className="w-full border-t border-dashed border-gray-100" />
          ))}
        </div>
        <div className="relative z-10 flex items-end gap-8 h-full px-4">
          {data.map((item) => (
            <div key={item.platform} className="flex-1 flex flex-col items-center gap-4">
              <div className="flex flex-col justify-end items-center h-56 w-full">
                <div
                  className="w-full max-w-[56px] rounded-3xl rounded-b-none bg-gradient-to-t from-indigo-500 via-purple-400 to-indigo-200 shadow-lg transition-all duration-700 ease-out hover:shadow-xl"
                  style={{ height: animated ? `${(item.value / max) * 100}%` : '0%' }}
                />
              </div>
              <div className="text-center space-y-2">
                <p className="text-lg font-bold text-gray-900">{item.value.toLocaleString('en-US')}</p>
                <p className="text-sm font-medium text-gray-600 uppercase tracking-wider">{item.platform}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <p className="text-xs text-gray-400 text-center font-medium">Sample conversions per platform • Replace with live API data when available</p>
    </div>
  );
};

const FunnelVisualizer: React.FC<{ steps: { label: string; value: number; color: string }[] }> = ({ steps }) => {
  const animated = useAnimatedReveal();
  return (
    <div className="space-y-6">
      {steps.map((step, index) => {
        const percent = ((steps.length - index) / steps.length) * 100;
        const topRadius = 18 - index * 4;
        return (
          <div key={step.label} className="flex items-center gap-6">
            <div
              className="h-12 transition-all duration-700 ease-out shadow-sm"
              style={{
                width: animated ? `${percent}%` : '0%',
                maxWidth: '100%',
                background: `linear-gradient(90deg, ${step.color}, ${step.color})`,
                borderTopLeftRadius: `${topRadius}px`,
                borderTopRightRadius: `${topRadius}px`,
                borderBottomLeftRadius: `${Math.max(topRadius - 4, 4)}px`,
                borderBottomRightRadius: `${Math.max(topRadius - 4, 4)}px`,
              }}
            />
            <div className="text-sm min-w-[120px]">
              <p className="font-semibold text-gray-900 text-base">{step.label}</p>
              <p className="text-2xl font-bold text-gray-800">{step.value.toLocaleString('en-US')}</p>
            </div>
          </div>
        );
      })}
      <div className="flex gap-4 text-xs text-gray-500">
        {steps.map((step) => (
          <span key={step.label} className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full" style={{ backgroundColor: step.color }} />
            {step.label}
          </span>
        ))}
      </div>
    </div>
  );
};

interface DashboardProps {
  onLogout?: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const {
    metrics: rawMetrics,
    loading: metricsLoading,
    error: metricsError,
    refetch: refetchMetrics,
  } = useMetrics();
  const {
    campaigns,
    loading: campaignsLoading,
    error: campaignsError,
    refetch: refetchCampaigns,
  } = useCampaigns();
  const [activeSection, setActiveSection] = useState<SectionKey>('overview');
  const initialRealtime = mockOverviewRealtime['7D']?.[0]?.id || 'active-now';
  const [selectedRealtimeId, setSelectedRealtimeId] = useState<string>(initialRealtime);
  const [selectedRange, setSelectedRange] = useState<'Today' | '7D' | '30D'>('7D');
  const [compareMode, setCompareMode] = useState<'previous' | 'target'>('previous');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [productCategory, setProductCategory] = useState<string>('All');
  const filterOptions = [
    { key: '1d', label: 'Last 1 Day' },
    { key: '7d', label: 'Last 7 Days' },
    { key: '30d', label: 'Last 30 Days' },
    { key: '90d', label: 'Last 90 Days' },
    { key: '365d', label: 'Last 365 Days' },
  ] as const;
  type DateRangeKey = typeof filterOptions[number]['key'] | 'custom';
  const [campaignDateRange, setCampaignDateRange] = useState<DateRangeKey>('30d');
  const [campaignFilterOpen, setCampaignFilterOpen] = useState(false);
  const [globalDateRange, setGlobalDateRange] = useState<DateRangeKey>('30d');
  const [globalFilterOpen, setGlobalFilterOpen] = useState(false);
  const [customDateRange, setCustomDateRange] = useState<{ start: string; end: string }>({ start: '', end: '' });
  const [headerSearch, setHeaderSearch] = useState('');
  const [calendarSelection, setCalendarSelection] = useState<{ start: string; end: string }>({ start: '', end: '' });
  const [calendarOpen, setCalendarOpen] = useState(false);

  const isLoading = metricsLoading || campaignsLoading;
  const error = metricsError || campaignsError;

  const chartSeries: ChartDatum[] = useMemo(
    () =>
      rawMetrics.map((point) => ({
        date: point.date,
        impressions: point.impressions ?? 0,
        clicks: point.clicks ?? 0,
        conversions: point.conversions ?? 0,
        spend: Number(point.spend || 0),
        revenue: Number(point.revenue || 0),
      })),
    [rawMetrics]
  );

  const aggregated = useMemo(() => {
    const totals = chartSeries.reduce(
      (acc, point) => ({
        impressions: acc.impressions + Number(point.impressions || 0),
        clicks: acc.clicks + Number(point.clicks || 0),
        conversions: acc.conversions + Number(point.conversions || 0),
        spend: acc.spend + Number(point.spend || 0),
        revenue: acc.revenue + Number(point.revenue || 0),
      }),
      { impressions: 0, clicks: 0, conversions: 0, spend: 0, revenue: 0 }
    );

    const platformTotals: Record<string, number> = {};
    campaigns.forEach((campaign) => {
      const revenue = (campaign.metrics || []).reduce((sum, metric) => sum + Number(metric.revenue || 0), 0);
      platformTotals[campaign.platform] = (platformTotals[campaign.platform] || 0) + revenue;
    });

    const platformBreakdown = Object.entries(platformTotals).map(([platform, value]) => ({
      name: platform.toUpperCase(),
      value,
    }));

    return { totals, platformBreakdown };
  }, [chartSeries, campaigns]);

  const campaignTotals = useMemo(
    () =>
      campaigns.reduce(
        (acc, campaign) => {
          (campaign.metrics || []).forEach((metric) => {
            acc.spend += Number(metric.spend || 0);
            acc.revenue += Number(metric.revenue || 0);
            acc.orders += Number(metric.orders || 0);
          });
          return acc;
        },
        { spend: 0, revenue: 0, orders: 0 }
      ),
    [campaigns]
  );

  const currentRealtimeStats = useMemo(() => {
    return mockOverviewRealtime[selectedRange] || mockOverviewRealtime['7D'];
  }, [selectedRange]);

  useEffect(() => {
    if (!currentRealtimeStats?.length) return;
    if (!currentRealtimeStats.find((stat) => stat.id === selectedRealtimeId)) {
      setSelectedRealtimeId(currentRealtimeStats[0].id);
    }
  }, [currentRealtimeStats, selectedRealtimeId]);

  const activeRealtimeStat = useMemo(
    () => currentRealtimeStats.find((stat) => stat.id === selectedRealtimeId) || currentRealtimeStats[0],
    [currentRealtimeStats, selectedRealtimeId]
  );

  const productCategories = useMemo(() => {
    const categories = Array.from(new Set(mockProductPerformance.map((product) => product.category)));
    return ['All', ...categories];
  }, []);

  const filteredProductPerformance = useMemo(() => {
    if (productCategory === 'All') return mockProductPerformance;
    return mockProductPerformance.filter((product) => product.category === productCategory);
  }, [productCategory]);

  useEffect(() => {
    const existing = document.querySelector('link[data-fontawesome="true"]') as HTMLLinkElement | null;
    if (existing) {
      return;
    }

    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css';
    link.crossOrigin = 'anonymous';
    link.referrerPolicy = 'no-referrer';
    link.dataset.fontawesome = 'true';
    document.head.appendChild(link);

    return () => {
      if (link.parentNode) {
        link.parentNode.removeChild(link);
      }
    };
  }, []);

  const menuItems = useMemo(
    () =>
      [
        { label: 'Overview Dashboard', icon: <LayoutDashboard />, key: 'overview' as SectionKey },
        { label: 'Campaign Performance', icon: <BarChart3 />, key: 'campaign' as SectionKey },
        { label: 'SEO & Web Analytics', icon: <Search />, key: 'seo' as SectionKey },
        { label: 'E-commerce Insights', icon: <ShoppingBag />, key: 'commerce' as SectionKey },
        { label: 'CRM & Leads Insights', icon: <Users />, key: 'crm' as SectionKey },
        { label: 'Trend Analysis', icon: <TrendingUp />, key: 'trend' as SectionKey },
        { label: 'Settings', icon: <Settings />, key: 'settings' as SectionKey },
        { label: 'Reports & Automation', icon: <FileText />, key: 'reports' as SectionKey },
      ].map((item) => ({
        ...item,
        active: item.key === activeSection,
        onClick: () => setActiveSection(item.key),
      })),
    [activeSection]
  );

  const handleRefresh = () => {
    refetchMetrics();
    refetchCampaigns();
  };

  const renderOverview = () => (
    <div className="space-y-8">
      <section className="bg-white rounded-3xl shadow p-6 space-y-6">
        <div className="flex flex-col gap-4">
          <SectionTitle title="Overview Dashboard" subtitle="Real-time marketing performance insights" />
          <div className="flex flex-wrap items-center gap-3 text-xs text-gray-500">
            <span className="uppercase tracking-[0.3em] text-gray-400">Range</span>
            {(['Today', '7D', '30D'] as const).map((range) => (
              <button
                key={range}
                onClick={() => setSelectedRange(range)}
                className={`rounded-full border px-3 py-1 font-semibold ${selectedRange === range ? 'bg-gray-900 text-white border-gray-900' : 'border-gray-200 text-gray-700'}`}
              >
                {range}
              </button>
            ))}
            <span className="ml-4 uppercase tracking-[0.3em] text-gray-400">Compare</span>
            {(['previous', 'target'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setCompareMode(mode)}
                className={`rounded-full border px-3 py-1 font-semibold capitalize ${compareMode === mode ? 'bg-gray-900 text-white border-gray-900' : 'border-gray-200 text-gray-700'}`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-3xl border border-gray-100 bg-white shadow p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-gray-900">Real-Time Analytics</p>
              <p className="text-xs text-gray-500">Monitors live marketing signals</p>
            </div>
            <p className="text-xs text-gray-500">+6.5% vs last period</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {currentRealtimeStats.map((stat) => (
              <RealTimeCard
                key={stat.id}
                label={stat.label}
                value={stat.value}
                delta={compareMode === 'previous' ? stat.delta : stat.deltaTarget || stat.delta}
                positive={stat.positive}
                active={stat.id === selectedRealtimeId}
                onSelect={() => setSelectedRealtimeId(stat.id)}
              />
            ))}
          </div>
          <div className="rounded-2xl bg-gray-50 border border-dashed border-gray-200 p-5 text-sm text-gray-600 flex flex-wrap gap-6">
            <div className="space-y-1 min-w-[150px]">
              <p className="text-xs uppercase tracking-[0.2em] text-gray-500">Focused metric</p>
              <p className="text-base font-semibold text-gray-900">{activeRealtimeStat?.label}</p>
            </div>
            <div className="space-y-1 min-w-[120px]">
              <p className="text-xs uppercase tracking-[0.2em] text-gray-500">Range</p>
              <p className="text-base font-semibold text-gray-900">{selectedRange}</p>
            </div>
            <div className="space-y-1 min-w-[170px]">
              <p className="text-xs uppercase tracking-[0.2em] text-gray-500">Comparison</p>
              <p className="text-base font-semibold text-gray-900">{compareMode === 'previous' ? 'Previous period' : 'Quarter target'}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="rounded-3xl border border-gray-100/60 bg-gradient-to-br from-white to-indigo-50/20 p-6 space-y-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-lg font-semibold text-gray-900 flex items-center gap-3">
                  <i className="fa-solid fa-chart-simple text-indigo-500 text-xl" /> Financial Overview
                </p>
                <p className="text-sm text-gray-600 font-medium">ROI {mockFinancialOverview.roi} ({mockFinancialOverview.roiChange})</p>
              </div>
              <button className="text-sm font-medium text-indigo-600 hover:text-indigo-700 transition-colors px-3 py-1 rounded-lg hover:bg-indigo-50">Download CSV</button>
            </div>
            <DonutChart segments={mockFinancialOverview.breakdown} />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-sm">
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-600 uppercase tracking-wider">Total Revenue</p>
                <p className="text-2xl font-bold text-gray-900">THB {mockFinancialOverview.revenue.toLocaleString('en-US')}</p>
                <p className="text-sm font-medium text-emerald-600">{mockFinancialOverview.revenueChange}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-600 uppercase tracking-wider">Total Profit</p>
                <p className="text-2xl font-bold text-gray-900">THB {mockFinancialOverview.profit.toLocaleString('en-US')}</p>
                <p className="text-sm font-medium text-emerald-600">{mockFinancialOverview.profitChange}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-600 uppercase tracking-wider">Total Cost</p>
                <p className="text-2xl font-bold text-gray-900">THB {mockFinancialOverview.cost.toLocaleString('en-US')}</p>
                <p className="text-sm font-medium text-red-600">{mockFinancialOverview.costChange}</p>
              </div>
            </div>
          </div>
          <div className="rounded-3xl border border-gray-100/60 bg-gradient-to-br from-white to-purple-50/20 p-6 space-y-6 shadow-sm">
            <div className="space-y-2">
              <p className="text-lg font-semibold text-gray-900">User Conversion Funnel</p>
              <p className="text-sm text-gray-600">Track user journey through conversion stages</p>
            </div>
            <FunnelVisualizer steps={mockConversionFunnel} />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="rounded-2xl border border-gray-100 p-4 space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-base font-semibold text-gray-900">LTV : CAC Ratio</p>
              <p className="text-xs text-gray-500">Goal ≥ 3.0</p>
            </div>
            <div className="overflow-x-auto pb-2">
              <LtvComparisonChart data={mockLtvTrend} />
            </div>
            <div className="flex flex-wrap items-start gap-8 text-sm text-gray-700">
              <div className="space-y-1">
                <p className="uppercase text-[11px] text-gray-500 tracking-[0.2em]">Current Ratio</p>
                <p className="text-3xl font-bold text-gray-900">3.4x</p>
              </div>
              <div className="space-y-1">
                <p className="uppercase text-[11px] text-gray-500 tracking-[0.2em]">Trend</p>
                <p className="text-emerald-500 text-base font-semibold">+0.2 vs last month</p>
              </div>
            </div>
          </div>
          <div className="rounded-3xl border border-gray-100/60 bg-gradient-to-br from-white to-indigo-50/20 p-6 space-y-6 shadow-sm">
            <div className="space-y-2">
              <p className="text-lg font-semibold text-gray-900">Conversions Platform</p>
              <p className="text-sm text-gray-600">Performance breakdown by platform</p>
            </div>
            <ConversionPlatformBars data={mockConversionPlatforms} />
          </div>
        </div>

        <div className="rounded-2xl border border-gray-100 p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <i className="fa-solid fa-box-open text-indigo-500" /> Product Performance
              </p>
              <p className="text-sm text-gray-500">Sample data table • Refreshed hourly</p>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <label className="text-gray-500 uppercase tracking-[0.2em] text-[11px]">Category</label>
              <select
                value={productCategory}
                onChange={(event) => setProductCategory(event.target.value)}
                className="rounded-full border border-gray-200 bg-white px-4 py-2 font-semibold text-gray-800 text-base focus:outline-none"
              >
                {productCategories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-base">
              <thead>
                <tr className="text-left text-[12px] uppercase tracking-[0.2em] text-gray-500">
                  <th className="py-3 pr-6 whitespace-nowrap font-semibold">Product Name</th>
                  <th className="py-3 pr-6 whitespace-nowrap font-semibold">Category</th>
                  <th className="py-3 pr-6 whitespace-nowrap font-semibold">Sales</th>
                  <th className="py-3 pr-6 whitespace-nowrap font-semibold">Revenue</th>
                  <th className="py-3 pr-6 whitespace-nowrap font-semibold">Stock</th>
                  <th className="py-3 whitespace-nowrap font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredProductPerformance.map((product) => (
                  <tr key={product.name} className="text-gray-800">
                    <td className="py-4 pr-6 font-semibold text-gray-900">{product.name}</td>
                    <td className="py-4 pr-6 text-gray-600">{product.category}</td>
                    <td className="py-4 pr-6 whitespace-nowrap font-semibold">{product.sales.toLocaleString('en-US')}</td>
                    <td className="py-4 pr-6 whitespace-nowrap font-semibold">THB {product.revenue.toLocaleString('en-US')}</td>
                    <td className="py-4 pr-6 whitespace-nowrap">{product.stock}</td>
                    <td className="py-4">
                      <span className="px-4 py-1.5 rounded-full text-[12px] uppercase tracking-wide bg-gray-900 text-white">
                        {product.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );

  const renderCommerce = () => (
    <div className="space-y-8">
      <section className="bg-gradient-to-br from-[#fff5ec] to-white rounded-3xl p-6 shadow-lg space-y-6">
        <SectionTitle title="E-commerce Insights" subtitle="Track and optimize your marketing campaigns" />

        <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-gray-900">Real-Time Analytics</p>
              <p className="text-xs text-gray-500">Live KPI snapshot across your store</p>
            </div>
            <p className="text-xs text-gray-500">+6.5% vs last period</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            {mockCommerceRealtime.map((stat) => (
              <RealTimeCard key={stat.id} label={stat.label} value={stat.value} delta={stat.helper} positive={stat.positive} />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          <ProfitabilityChart data={mockCommerceProfitability} />
          <CommerceFunnelChart steps={mockCommerceConversionFunnel} />
        </div>

        <div className="space-y-4">
          <RevenueOrdersTrendChart data={mockCommerceRevenueTrend} />
          <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-base font-semibold text-gray-900">Product Performance</p>
              <p className="text-sm text-gray-500">Mock table • Updated hourly</p>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full text-base">
                <thead>
                  <tr className="text-left text-[12px] uppercase tracking-[0.2em] text-gray-500">
                    <th className="py-3 pr-6">Product Name</th>
                    <th className="py-3 pr-6">Category</th>
                    <th className="py-3 pr-6">Sales</th>
                    <th className="py-3 pr-6">Revenue</th>
                    <th className="py-3 pr-6">Stock</th>
                    <th className="py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {mockProductPerformance.map((product) => (
                    <tr key={product.name} className="text-gray-800">
                      <td className="py-4 pr-6 font-semibold">{product.name}</td>
                      <td className="py-4 pr-6 text-gray-500">{product.category}</td>
                      <td className="py-4 pr-6">{product.sales.toLocaleString('en-US')}</td>
                      <td className="py-4 pr-6">THB {product.revenue.toLocaleString('en-US')}</td>
                      <td className="py-4 pr-6">{product.stock}</td>
                      <td className="py-4">
                        <span className="px-4 py-1.5 rounded-full text-[12px] uppercase tracking-wide bg-gray-900 text-white">
                          {product.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-gray-900">Creative previews</p>
            <p className="text-xs text-gray-500">Mock cards • Replace with live assets later</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {mockCommerceCreatives.map((creative) => (
              <div key={creative.id} className="rounded-3xl border border-gray-100 bg-white p-4 space-y-4 shadow-sm">
                <div className="aspect-video w-full rounded-2xl bg-gray-100" />
                <div className="space-y-1">
                  <p className="text-base font-semibold text-gray-900">{creative.name}</p>
                  <p className="text-xs text-gray-500">Type: {creative.type}</p>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.2em] text-gray-400">Reach</p>
                    <p className="font-semibold text-gray-900">{creative.reach.toLocaleString('en-US')}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[11px] uppercase tracking-[0.2em] text-gray-400">Reactions</p>
                    <p className="font-semibold text-gray-900">{creative.reactions.toLocaleString('en-US')}</p>
                  </div>
                </div>
                <div className="flex justify-start">
                  <span className="inline-flex items-center justify-center rounded-full bg-gray-900 text-white text-xs px-4 py-1 uppercase tracking-wide">
                    {creative.cta}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-3xl border border-gray-100 bg-white p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-sm font-semibold text-gray-900">Product Video Performance</p>
              <p className="text-xs text-gray-500">Monitor shoppable video creatives across channels</p>
            </div>
            <button className="px-3 py-1 rounded-full border border-gray-200 text-xs font-semibold text-gray-700">
              Export CSV
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="text-left text-[11px] uppercase tracking-[0.2em] text-gray-500">
                  <th className="py-2 pr-4">Product</th>
                  <th className="py-2 pr-4">Campaign</th>
                  <th className="py-2 pr-4">Platform</th>
                  <th className="py-2 pr-4">Format</th>
                  <th className="py-2 pr-4">Length</th>
                  <th className="py-2 pr-4">Views</th>
                  <th className="py-2 pr-4">Completion</th>
                  <th className="py-2 pr-4">CTR</th>
                  <th className="py-2 pr-4">Revenue</th>
                  <th className="py-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {mockCommerceProductVideos.map((video) => (
                  <tr key={video.id} className="text-gray-800">
                    <td className="py-3 pr-4 font-semibold text-gray-900">{video.product}</td>
                    <td className="py-3 pr-4 text-gray-600">{video.campaign}</td>
                    <td className="py-3 pr-4 text-gray-600">{video.platform}</td>
                    <td className="py-3 pr-4 text-gray-600">{video.format}</td>
                    <td className="py-3 pr-4 text-gray-600">{video.length}</td>
                    <td className="py-3 pr-4">{video.views.toLocaleString('en-US')}</td>
                    <td className="py-3 pr-4">{video.completionRate}</td>
                    <td className="py-3 pr-4">{video.ctr}</td>
                    <td className="py-3 pr-4">THB {video.revenue.toLocaleString('en-US')}</td>
                    <td className="py-3">
                      <span
                        className={`px-3 py-1 rounded-full text-[11px] uppercase tracking-wide ${
                          video.status === 'Active'
                            ? 'bg-emerald-50 text-emerald-600'
                            : video.status === 'Learning'
                            ? 'bg-amber-50 text-amber-600'
                            : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        {video.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );

  const renderCampaign = () => (
    <div className="space-y-8">
      <section className="bg-gradient-to-br from-[#fff5ec] to-white rounded-3xl p-6 shadow-lg space-y-6">
        <SectionTitle
          title="Campaign Performance"
          subtitle="Track and optimize your marketing campaigns"
          badge={<span className="rounded-full border border-orange-200 bg-white/70 px-4 py-1 text-xs font-semibold text-orange-600">Demonstration data • Mock dataset</span>}
          actions={
            <div className="flex items-center gap-2 flex-wrap">
              <span className="rounded-full border border-gray-200 bg-white px-4 py-2 text-xs font-semibold uppercase tracking-[0.35em] text-gray-500">
                Last 30 Days
              </span>
              <button className="inline-flex items-center gap-2 rounded-full border border-gray-200 bg-white px-5 py-2 text-sm font-semibold text-gray-800" onClick={handleRefresh}>
                <RefreshCw className="h-4 w-4" /> Refresh mock
              </button>
              <div className="relative">
                <button
                  className="inline-flex items-center gap-2 rounded-full border border-gray-200 bg-white px-5 py-2 text-sm font-semibold text-gray-800"
                  onClick={() => setCampaignFilterOpen((prev) => !prev)}
                >
                  <Filter className="h-4 w-4" /> {filterOptions.find((option) => option.key === campaignDateRange)?.label || 'Filter'}
                </button>
                {campaignFilterOpen && (
                  <div className="absolute right-0 mt-2 w-48 rounded-2xl border border-gray-100 bg-white p-3 shadow-2xl z-10">
                    {filterOptions.map((option) => (
                      <button
                        key={option.key}
                        onClick={() => {
                          setCampaignDateRange(option.key);
                          setCampaignFilterOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 rounded-xl text-sm font-semibold ${
                          campaignDateRange === option.key ? 'bg-gray-900 text-white' : 'text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        {option.label}
                      </button>
                    ))}
                    <button className="w-full mt-2 rounded-xl border border-gray-200 px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
                      Custom
                    </button>
                  </div>
                )}
              </div>
            </div>
          }
        />

        <CampaignSourceTabs sources={mockCampaignSourceInsights} />
      </section>
    </div>
  );

  const renderSEO = () => (
    <div className="space-y-8">
      <section className="bg-white rounded-3xl shadow-lg p-6 space-y-6">
        <SectionTitle title="SEO & Web Analytics" subtitle="Real-time SERP visibility & organic insights" />
        <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-gray-900">Real-Time Analytics</p>
              <p className="text-xs text-gray-500">Organic KPIs styled to mirror the Overview Dashboard</p>
            </div>
            <span className="text-xs text-gray-500 uppercase tracking-[0.3em]">SEO Focus</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            {mockSeoRealtimeStats.map((stat) => (
              <RealTimeCard key={stat.id} label={stat.label} value={stat.value} delta={stat.delta} positive={stat.positive} />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="space-y-4 xl:col-span-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <SeoAuthorityCard />
              <SeoOrganicSummaryCard />
            </div>
            <SearchVisibilityCard snapshot={mockSeoSnapshots} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <SeoConversionCard summary={mockSeoConversionSummary} />
              <SeoIssuesCard issues={mockSeoIssues} />
            </div>
            <SeoKeywordsTable keywords={mockSeoKeywordsDetailed} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <SeoCompetitorsCard competitors={mockSeoCompetitors} />
              <SeoPositionDistributionCard distribution={mockSeoPositionDistribution} />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <SeoBacklinkSummaryCard />
              <SeoCompetitiveMapCard snapshot={mockSeoCompetitiveMap} />
            </div>
          </div>
          <div className="xl:col-span-1 space-y-4">
            <SeoRegionalPerformanceCard />
            <TechnicalScoreList scores={mockSeoTechnicalScores} />
            <SeoChannelMix channels={mockSeoSnapshots.channels} />
            <SeoRightRailCard />
          </div>
        </div>
      </section>
    </div>
  );

  const renderTrend = () => (
    <div className="space-y-8">
      <section className="bg-gradient-to-br from-[#fff5ec] to-white rounded-3xl p-6 shadow-lg space-y-6">
        <SectionTitle title="Trend Analysis & History" subtitle="Track your metrics over time and compare performance across periods" />

        <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-gray-900">Real-Time Analytics</p>
              <p className="text-xs text-gray-500">Comparative metrics this period vs last</p>
            </div>
            <button className="px-3 py-1 rounded-full border border-gray-200 text-xs">Filter</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            {mockTrendRealtime.map((stat) => (
              <RealTimeCard key={stat.id} label={stat.label} value={stat.value} delta={stat.delta} positive={stat.positive} />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          <ChannelComparisonChart data={mockTrendRevenueByChannel} />
          <SalesFunnelChart stages={mockTrendSalesFunnel} />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
          <div className="xl:col-span-2">
            <RevenueTrendChart data={mockTrendRevenueTrend} />
          </div>
          <YtdRevenueCard data={mockTrendRevenueTrend} />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          <LeadSourceTable sources={mockTrendLeadSources} />
          <SalesRepTable reps={mockTrendSalesReps} />
        </div>
      </section>
    </div>
  );

  const renderCRM = () => (
    <div className="space-y-8">
      <section className="bg-gradient-to-br from-[#fff5ec] to-white rounded-3xl p-6 shadow-lg space-y-6">
        <SectionTitle title="CRM & Leads" subtitle="Track leads, analyze customers, and manage integrations" />

        <div className="rounded-3xl border border-gray-100 bg-white p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-gray-900">Real-Time Analytics</p>
              <p className="text-xs text-gray-500">Performance overview for your pipeline</p>
            </div>
            <p className="text-xs text-gray-500">+6.5% from last period</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            {mockCrmRealtime.map((stat) => (
              <RealTimeCard key={stat.id} label={stat.label} value={stat.value} delta={stat.delta} positive={stat.positive} />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          <CrmStageChart stages={mockCrmStages} />
          <CrmAgeDonut ranges={mockCrmAgeRange} />
        </div>

        <LeadTrackingTable leads={mockCrmLeads} />
      </section>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-8">
      <section className="bg-gradient-to-br from-[#fff5ec] to-white rounded-3xl p-6 shadow-lg space-y-6">
        <SectionTitle title="Settings" subtitle="Track and optimize your marketing campaigns" />

        <KpiSettingsTable />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <ThemeBrandingCard />
          <DataRefreshCard />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <ApiIntegrationCard />
          <UserRolesCard />
        </div>

        <AlertSettingsCard />
      </section>
    </div>
  );

  const renderReports = () => (
    <div className="space-y-8">
      <section className="bg-gradient-to-br from-[#fff5ec] to-white rounded-3xl p-6 shadow-lg space-y-6">
        <SectionTitle title="Reports & Automation" subtitle="Track and optimize your marketing campaigns" />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {mockReportBuilders.builders.map((builder) => (
            <ReportBuilderCard key={builder.id} builder={builder} actionLabel="Download" />
          ))}
          <ScheduleReportCard schedule={mockReportBuilders.schedule} />
        </div>

        <ReportStatusTable />
      </section>
    </div>
  );

  const renderSection = () => {
    switch (activeSection) {
      case 'overview':
        return renderOverview();
      case 'commerce':
        return renderCommerce();
      case 'campaign':
        return renderCampaign();
      case 'crm':
        return renderCRM();
      case 'trend':
        return renderTrend();
      case 'seo':
        return renderSEO();
      case 'settings':
        return renderSettings();
      case 'reports':
        return renderReports();
      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-[#fdf6f0]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-[#fdf6f0] flex items-center justify-center">
        <div className="bg-red-50 border border-red-200 text-red-700 px-6 py-4 rounded-xl max-w-md">
          <p className="font-semibold mb-1">Unable to load dashboard data</p>
          <p className="text-sm">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <DashboardShell
      title={
        activeSection === 'overview'
          ? 'Overview Dashboard'
          : activeSection === 'campaign'
          ? 'Campaign Performance'
          : activeSection === 'seo'
          ? 'SEO & Web Analytics'
          : activeSection === 'commerce'
          ? 'E-commerce Insights'
          : activeSection === 'crm'
          ? 'CRM & Leads'
          : activeSection === 'trend'
          ? 'Trend Analysis'
          : activeSection === 'settings'
          ? 'Settings'
          : 'Reports & Automation'
      }
      subtitle="Demonstration data prepared for UX/UI validation (mock dataset)"
      roleLabel="Admin Overview"
      menuItems={menuItems}
      actions={
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2">
            <button
              className="inline-flex items-center gap-2 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-700"
              onClick={handleRefresh}
            >
              <RefreshCw className="h-4 w-4" /> Refresh mock
            </button>
            <button className="inline-flex items-center gap-2 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-700">
              <Share2 className="h-4 w-4" /> Share
            </button>
            <button
              className={`inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium ${
                notificationsEnabled ? 'border-emerald-200 bg-emerald-50 text-emerald-700' : 'border-gray-200 bg-white text-gray-700'
              }`}
              onClick={() => setNotificationsEnabled((prev) => !prev)}
            >
              <Bell className="h-4 w-4" /> {notificationsEnabled ? 'Notifications on' : 'Notifications off'}
            </button>
          </div>
          <div className="flex items-center rounded-full border border-gray-200 bg-white px-4 py-2 text-sm text-gray-600 shadow-sm w-full md:w-auto min-w-[240px]">
            <Search className="h-4 w-4 text-gray-400 mr-2" />
            <input
              type="text"
              value={headerSearch}
              onChange={(event) => setHeaderSearch(event.target.value)}
              placeholder="Search dashboard"
              className="flex-1 bg-transparent focus:outline-none text-sm text-gray-800"
            />
          </div>
          <div className="relative">
            <button
              className="inline-flex items-center px-4 py-2 rounded-full bg-white shadow-md text-sm font-medium text-gray-800 hover:shadow-lg transition"
              onClick={() => setGlobalFilterOpen((prev) => !prev)}
            >
              <Filter className="h-4 w-4 mr-2" /> {filterOptions.find((option) => option.key === globalDateRange)?.label || 'Filter'}
            </button>
            {globalFilterOpen && (
              <div className="absolute right-0 mt-2 w-52 rounded-2xl border border-gray-100 bg-white p-2 shadow-lg z-20 space-y-1">
                {filterOptions.map((option) => (
                  <button
                    key={option.key}
                    onClick={() => {
                      setGlobalDateRange(option.key);
                      setGlobalFilterOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-xl text-sm font-medium ${
                      globalDateRange === option.key ? 'bg-gray-900 text-white' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-gray-100">
                  <label className="text-[11px] uppercase tracking-[0.2em] text-gray-400 col-span-2">Custom range</label>
                  <input
                    type="date"
                    value={customDateRange.start}
                    onChange={(event) => setCustomDateRange((prev) => ({ ...prev, start: event.target.value }))}
                    className="rounded-xl border border-gray-200 px-2 py-1 text-sm text-gray-700 focus:outline-none"
                  />
                  <input
                    type="date"
                    value={customDateRange.end}
                    onChange={(event) => setCustomDateRange((prev) => ({ ...prev, end: event.target.value }))}
                    className="rounded-xl border border-gray-200 px-2 py-1 text-sm text-gray-700 focus:outline-none"
                  />
                  <button
                    className="col-span-2 rounded-xl bg-gray-900 text-white text-sm font-semibold py-2"
                    onClick={() => {
                      setGlobalFilterOpen(false);
                      setGlobalDateRange('custom');
                    }}
                  >
                    Apply range
                  </button>
                </div>
              </div>
            )}
          </div>
          <div className="relative">
            <button
              className="inline-flex items-center justify-center rounded-full border border-gray-200 bg-white p-3 text-gray-700 shadow-sm hover:shadow-md transition"
              onClick={() => setCalendarOpen((prev) => !prev)}
              aria-label="Open calendar"
            >
              <Calendar className="h-5 w-5" />
            </button>
            {calendarOpen && (
              <div className="absolute right-0 mt-2 w-72 rounded-3xl border border-gray-100 bg-white p-4 shadow-2xl space-y-4 z-30">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-gray-900">Select date range</p>
                  <button className="text-xs text-gray-400 hover:text-gray-600" onClick={() => setCalendarOpen(false)}>
                    Close
                  </button>
                </div>
                <div className="space-y-3">
                  <div>
                    <label className="text-[11px] uppercase tracking-[0.2em] text-gray-400">From</label>
                    <input
                      type="date"
                      value={calendarSelection.start}
                      onChange={(event) => setCalendarSelection((prev) => ({ ...prev, start: event.target.value }))}
                      className="mt-1 w-full rounded-xl border border-gray-200 px-3 py-2 text-sm text-gray-700 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] uppercase tracking-[0.2em] text-gray-400">To</label>
                    <input
                      type="date"
                      value={calendarSelection.end}
                      onChange={(event) => setCalendarSelection((prev) => ({ ...prev, end: event.target.value }))}
                      className="mt-1 w-full rounded-xl border border-gray-200 px-3 py-2 text-sm text-gray-700 focus:outline-none"
                    />
                  </div>
                </div>
                {calendarSelection.start && calendarSelection.end ? (
                  <p className="text-xs text-gray-500">
                    Showing data for {format(new Date(calendarSelection.start), 'dd MMM yyyy')} – {format(new Date(calendarSelection.end), 'dd MMM yyyy')}
                  </p>
                ) : (
                  <p className="text-xs text-gray-400">Select a start and end date to filter dashboard metrics.</p>
                )}
                <div className="flex justify-end gap-2">
                  <button
                    className="text-xs font-semibold text-gray-500 hover:text-gray-700"
                    onClick={() => {
                      setCalendarSelection({ start: '', end: '' });
                      setCalendarOpen(false);
                    }}
                  >
                    Clear
                  </button>
                  <button
                    className="rounded-full bg-gray-900 text-white text-sm font-semibold px-4 py-2"
                    onClick={() => setCalendarOpen(false)}
                  >
                    Apply
                  </button>
                </div>
              </div>
            )}
          </div>
          <NotificationCenter />
        </div>
      }
      onLogout={onLogout}
      onProfileClick={() => navigate('/profile')}
    >
      {renderSection()}
    </DashboardShell>
  );
};
